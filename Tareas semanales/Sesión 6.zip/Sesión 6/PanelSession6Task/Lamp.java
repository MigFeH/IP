
/**
 * Write a description of class Lamp here.
 * 
 * @author Miguel
 * @version 23-10-21
 */
public class Lamp
{
    public static final boolean LAMP_ON = true;   //Lámpara encendida
    public static final boolean LAMP_OFF = false;  //Lámpara apagada

    // instance variables - replace the example below with your own
    private boolean status;    //El estado de la bombilla

    /**
     * Constructor de la clase Lamp sin parámetros
     */
    public Lamp()
    {
        setStatus(LAMP_ON);   //Bombilla encendida en valores estándar
    }
    
    /**
     * Constructor de la clase Lamp con un parámetro
     */
    public Lamp(boolean param)
    {
        setStatus(param);
    }
    
    /**
     * El método setTurnLamp modificará el estado de la bombilla
     * 
     * @param el estado de la bombilla
     */
    private void setStatus(boolean param)
    {
        this.status = param;
    }
    
    /**
     * El método getTurnLamp retornará el estado de la bombilla
     * 
     * @return el estado de la bombilla
     */
    public boolean getStatus()
    {
        return status;
    }
    
    /**
     * El método turnOn encenderá la bombilla
     * 
     */
    public void turnOn()
    {
        setStatus(LAMP_ON);    //Enciende la bombilla
    }

    /**
     * El método turnOff apagará la bombilla
     * 
     */
    public void turnOff()
    {
        setStatus(LAMP_OFF);   //Apaga la bombilla
    }

    /**
     * El método toString devolverá “ENCENDIDA” o “APAGADA” en función del
     * estado de la bombilla.
     *
     * @return "ENCENDIDA" o "APAGADA"
     */
    public String toString()
    {
        if (getStatus())
        {
            return "ENCENDIDA";
        }
        return "APAGADA";
    }
}
