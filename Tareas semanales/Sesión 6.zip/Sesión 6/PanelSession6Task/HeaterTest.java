

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class HeaterTest.
 *
 * @author  Miguel
 * @version 23-10-21
 */
public class HeaterTest
{
    /*
     * Pruebas del método toString con distintas temperaturas
     * 1- Una temperatura dentro de los límites
     * 2- Una temperatura por debajo de los límites
     * 3- Una temperatura por encima de los límites
     */
    
    /*
     * Prueba 1 del método toString
     */
    @Test
    public void testToStringWithTemperatureInsideOfLimits(){
        Heater heater1 = new Heater();
        heater1.changeTemperature(12);
        assertEquals(12,heater1.getTemperature());
    }
    
    /*
     * Prueba 2 del método toString
     */
    @Test
    public void testToStringWithTemperatureBelowOfLimits(){
        try{
            Heater heater1 = new Heater();
            heater1.changeTemperature(9);
            fail("Esperaba salto de excepción");
        } catch (IllegalArgumentException e){
            assertEquals("La temperatura no puede ser inferior a 10ºC ni superior a 27ºC", e.getMessage());
        }
    }
    
    /*
     * Prueba 3 del método toString
     */
    @Test
    public void testToStringWithTemperatureUpperOfLimits(){
        try{
            Heater heater1 = new Heater();
            heater1.changeTemperature(28);
            fail("Esperaba salto de excepción");
        } catch (IllegalArgumentException e){
            assertEquals("La temperatura no puede ser inferior a 10ºC ni superior a 27ºC", e.getMessage());
        }
    }
    
    /*
     * Pruebas del método toString
     */
    @Test
    public void testToStringWithNormalParams(){
        Heater heater1 = new Heater();
        assertEquals("27.0ºC",heater1.getTemperature() + "ºC");
    }
}
