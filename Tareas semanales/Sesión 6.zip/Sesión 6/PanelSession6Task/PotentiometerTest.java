

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class PotentiometerTest.
 *
 * @author  Miguel
 * @version 23-10-21
 */
public class PotentiometerTest
{
    /*
     * Pruebas del método toString con distinas posiciones
     * 1- Una posición dentro de los límites
     * 2- Una posición por debajo de los límites
     * 3- Una posición por encima de los límites
     */
    
    /*
     * Prueba 1 del método toString
     */
    @Test
    public void testToStringInsideOfLimits(){
        Potentiometer pto1 = new Potentiometer(7);
        assertEquals(7 + "",pto1.toString());
    }
    
    /*
     * Prueba 2 del método toString
     */
    @Test
    public void testToStringBelowOfLimits(){
        try{
            Potentiometer pto1 = new Potentiometer();
            pto1.movePosition(-1);
            fail("Esperaba salto de excepción");
        }catch(IllegalArgumentException e){
            assertEquals("La posición no puede ser inferior a 0 ni superior a 10",e.getMessage());
        }
    }
    
    /*
     * Prueba 3 del método toString
     */
    @Test
    public void testToStringUpperOfLimits(){
        try{
            Potentiometer pto1 = new Potentiometer();
            pto1.movePosition(11);
            fail("Esperaba salto de excepción");
        }catch(IllegalArgumentException e){
            assertEquals("La posición no puede ser inferior a 0 ni superior a 10",e.getMessage());
        }
    }
}
