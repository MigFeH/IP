

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class LampTest.
 *
 * @author  Miguel
 * @version 23-10-21
 */
public class LampTest
{
    /*
     * Pruebas del método turnOn
     */
    @Test
    public void testTurnOn(){
        Lamp lamp1 = new Lamp(false);
        lamp1.turnOn();
        assertEquals(true,lamp1.getStatus());
    }
    
    /*
     * Pruebas del método turnOff
     */
    @Test
    public void testTurnOff(){
        Lamp lamp1 = new Lamp(true);
        lamp1.turnOff();
        assertEquals(false,lamp1.getStatus());
    }
    
    /*
     * Pruebas del método toString en distintas ocasiones
     * 1- Que la bombilla esté apagada
     * 2- Que la bombilla esté encencida
     */
    
    /*
     * Prueba 1 del método toString 
     */
    @Test
    public void testToStringWithLampOn(){
        Lamp lamp1 = new Lamp(true);
        assertEquals("ENCENDIDA", lamp1.toString());
    }
    
    /*
     * Prueba 2 del método toString 
     */
    @Test
    public void testToStringWithLampOff(){
        Lamp lamp1 = new Lamp(false);
        assertEquals("APAGADA", lamp1.toString());
    }
}
