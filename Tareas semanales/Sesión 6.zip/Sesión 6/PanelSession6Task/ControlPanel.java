
/**
 * La clase ControlPanel contendrá un interruptor y una bombilla
 * 
 * @author Miguel
 * @version 23-10-21
 */
public class ControlPanel
{
    // instance variables
    private Switch interruptor1; //Variable de tipo objeto de la clase Switch
    private Potentiometer pot1;    //Variable de tipo objeto de la clase Potentiometer
    private Heater heater1;  //Variable de tipo objeto de la clase Heater
    
    /**
     * Constructor sin parámetros de la clase ControlPanel
     */
    public ControlPanel()
    {
        setSwitch(new Switch());
        setPotentiometer(new Potentiometer());
        setHeater(new Heater());
    }
    
    /**
     * Constructor sin parámetros de la clase ControlPanel
     */
    public ControlPanel(boolean interruptorStatus, int potentiometerPosition, double heaterTemperature)
    {
        setSwitch(new Switch(interruptorStatus));
        setPotentiometer(new Potentiometer(potentiometerPosition));
        setHeater(new Heater(heaterTemperature));
    }
    
    private void setSwitch(Switch param)
    {
        this.interruptor1 = param;
    }
    
    private void setPotentiometer(Potentiometer param)
    {
        this.pot1 = param;
    }
    
    private void setHeater(Heater param)
    {
        this.heater1 = param;
    }
    
    public Switch getSwitch()
    {
        return this.interruptor1;
    }
    
    public Potentiometer getPotentiometer()
    {
        return this.pot1;
    }
    
    public Heater getHeater()
    {
        return this.heater1;
    }
    
    /**
     * Método print para mostrar por consola el estado completo del sistema
     * con una salida similar a ésta:
     * =========== Estado del PANEL ============
     * Interruptor: ON
     * Bombilla: ENCENDIDA
     * Potenciómetro: 10
     * Radiador: 27.0 ºC
     * 
     */
    public void print()
    {
        System.out.println("=========== Estado del PANEL ============"
            + "\n Interruptor: " + interruptor1
            + "\n Bombilla: " + interruptor1.getLamp()
            + "\n Potenciómetro: " + pot1
            + "\n Radiador: " + heater1
            + "\n==========================================");
    }

    /**
     * El método press permitirá:
     * Cambiar la posición del interruptor.
     * Encender la bombilla si el interruptor está en posición ON
     * Apagar la bombilla si el interruptor está en posición OFF.
     *
     */
    public void press()
    {
        if (interruptor1.getInterruptor() == Switch.ON) {  //Si el interruptor está encendido...
            interruptor1.press(); //Cambiar la posición del interruptor a apagado
            interruptor1.getLamp().turnOff();   //Y apagar la bombilla
        } else if (interruptor1.getInterruptor() == Switch.OFF){    //Si el interruptor está apagado...
            interruptor1.press(); //Cambiar la posición del interruptor a encendido
            interruptor1.getLamp().turnOn();     //Y encender la bombilla
        }
    }

    /**
     * El método movePotentiometer que permitirá:
     * 
     * Cambiar la posición del potenciómetro.
     * 
     * Cambiar el valor de la temperatura del radiador en función de la
     * posición del potenciómetro: 10 ºC si el potenciómetro está a 0 (el
     * mínimo posible en el radiador), 27ºC si el potenciómetro está a 10 (el
     * máximo posible en el radiador).
     *
     * @param la nueva posición del potenciómetro
     */
    public void movePotentiometer(int position)
    {
        pot1.movePosition(position);
        heater1.changeTemperature(10 + (1.7 * pot1.getPosition()));
    }
}
