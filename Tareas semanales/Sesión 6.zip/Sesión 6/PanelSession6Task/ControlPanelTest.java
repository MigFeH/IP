

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class ControlPanelTest.
 *
 * @author  Miguel
 * @version 23-10-21
 */
public class ControlPanelTest
{
    private ControlPanel ctr;
    
    @BeforeEach
    public void setUp()
    {
        ctr = new ControlPanel();
    }
    
    /*
     * Pruebas del método movePotentiometer en dos situaciones distintas
     * 1- Estando el potenciómetro en la posición 0
     * 2- Estando el potenciómetro en la posición 10
     */
    
    /*
     * Prueba 1 del método movePotentiometer
     */
    @Test
    public void testMovePotentiometer0(){
        ctr.movePotentiometer(0);
        assertEquals(10,ctr.getHeater().getTemperature());
    }
    
    /*
     * Prueba 2 del método movePotentiometer
     */
    @Test
    public void testMovePotentiometer10(){
        ctr.movePotentiometer(10);
        assertEquals(27,ctr.getHeater().getTemperature());
    }
}
