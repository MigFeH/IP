
/**
 * La clase Potentiometer representa un potenciómetro al que se
 * puede colocar en una posición entre 0 y 10 mediante métodos
 * 
 * @author Miguel
 * @version 23-10-21
 */
public class Potentiometer
{
    //Constantes
    public static final int LOWER_POSITION = 0; //Posición más baja permitida
    public static final int HIGHER_POSITION = 10; //Posición más alta permitida

    //instance variables
    private int position;   //La posición del potenciómetro

    /**
     * Constructor de la clase Potentiometer sin parámetros
     */
    public Potentiometer()
    {
        movePosition(HIGHER_POSITION);
    }

    /**
     * Constructor de la clase Potentiometer con parámetros
     */
    public Potentiometer(int position)
    {
        setPosition(position);
    }
    
    private void setPosition(int position)
    {
        this.position = position;
    }

    /**
     * El método getPosition retornará el valor de position
     *
     * @return el valo de position
     */
    public int getPosition()
    {
        return position;
    }

    /**
     * El método movePosition modifica el valor del atributo position
     * 
     * @param el nuevo valor para position
     */
    public void movePosition(int position)
    {
        checkParam(position >= LOWER_POSITION && position <= HIGHER_POSITION, "La posición no puede ser inferior a 0 ni superior a 10");
        setPosition(position);
    }

    /**
     * El método toString devolverá el valor de position
     *
     * @return el valor de position
     */
    public String toString()
    {
        return String.valueOf(getPosition());
    }

    //******** Métodos auxiliares
    /**
     * El método checkParam comprobará si se cumple la condición de tipo booleano
     * Si no se cumple, lanza una excepción con un mensaje
     */
    private void checkParam(boolean condition, String msg){
        if (!condition){
            throw new IllegalArgumentException(msg);
        }
    }
}
