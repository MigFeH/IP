
/**
 * La clase Switch representa un interruptor
 * 
 * @author Miguel
 * @version 23-10-21
 */
public class Switch
{
    //Constantes
    public static final boolean ON = true;  //Interruptor encendido
    public static final boolean OFF = false;    //Interruptor apagado

    // instance variables - replace the example below with your own
    private boolean status;    //El estado del interruptor
    private Lamp lamp;  //La bombilla de la clase Lamp
    /**
     * Constructor sin parámetros de la clase Switch
     */
    public Switch()
    {
        setLamp(new Lamp());
        setInterruptor(ON); //Interruptor encendido por defecto
    }
    
    /**
     * Constructor con parámetro de la clase Switch
     */
    public Switch(boolean interruptor)
    {
        this();
        setInterruptor(interruptor);
    }

    /**
     * El método setInterruptor modifica el estado del interruptor
     * 
     * @param el estado del interruptor
     */
    private void setInterruptor(boolean param)
    {
        this.status = param;
    }

    /**
     * El método getInterruptor devuelve el estado del interruptor
     * 
     * @return el estado del interruptor
     */
    public boolean getInterruptor()
    {
        return status;
    }
    
    public Lamp getLamp()
    {
        return this.lamp;
    }

    private void setLamp(Lamp param)
    {
        this.lamp = param;
    }
    
    /**
     * El método press conmuta entre los dos estados de la bombilla
     *
     */
    public void press()
    {
        if (getInterruptor()){  //Interruptor encendido pasa a ser apagado
            setInterruptor(OFF);
            lamp.turnOff();
        } else{ //Interruptor apagado pasa a ser encendido
            setInterruptor(ON);
            lamp.turnOn();
        }
    }

    /**
     * El método toString que devuelva “ON” o bien “OFF” 
     * en función del estado del interruptor.
     *
     * @return "ON" u "OFF"
     */
    public String toString()
    {
        if (getInterruptor())
        { 
            return "ON";
        }
        return "OFF";
    }
}
