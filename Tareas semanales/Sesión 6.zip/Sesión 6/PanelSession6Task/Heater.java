
/**
 * La clase Heater representa un radiador al que se le puede fijar
 * una temperatura entre 10 y 27 grados centígrados
 * 
 * @author Miguel 
 * @version 23-10-21
 */
public class Heater
{
    //Constantes
    public static final double MIN_TEMPERATURE = 10;    //Temperatura mínima del radiador
    public static final double MAX_TEMPERATURE= 27;     //Temperatura máxima del radiador

    // instance variables
    private double temperature; //La temperatura del radiador

    /**
     * Constructor de la clase Heater sin parámetros
     */
    public Heater()
    {
        setTemperature(MAX_TEMPERATURE);
    }

    /**
     * Constructor de la clase Heater con parámetros
     */
    public Heater(double temperature)
    {
        setTemperature(temperature);
    }

    /**
     * El método getTemperature retornará el valor del atributo temperature
     *
     * @return el valor de temperature
     */
    public double getTemperature()
    {
        return temperature;
    }

    /**
     * El método changeTemperature modifica el valor de la temperatura 
     * al valor recibido como parámetro
     *
     * @param la nueva temperatura
     */
    public void changeTemperature(double temperature)
    {
        checkParam(temperature >= MIN_TEMPERATURE && temperature <= MAX_TEMPERATURE, "La temperatura no puede ser inferior a 10ºC ni superior a 27ºC");
        setTemperature(temperature);
    }
    
    private void setTemperature(double param)
    {
        this.temperature = param;
    }

    /**
     * El método toString devolverá una cadena con el valor de su temperatura.
     * Ej. “25 ºC”.
     *
     * @return una cadena con el valor de la temperatura
     */
    public String toString()
    {
        return getTemperature() + "ºC";
    }


    //********* Métodos auxiliares
    /**
     * El método checkParam comprobará una condición
     * y si esa condición no se cumple, lanza una excepción con un mensaje 
     * 
     * @param la condición de tipo booleano
     */
    private void checkParam(boolean condition, String msg){
        if (!condition){
            throw new IllegalArgumentException(msg);
        }
    }
}
