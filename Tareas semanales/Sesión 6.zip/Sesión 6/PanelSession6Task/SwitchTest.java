

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class SwitchTest.
 *
 * @author  Miguel
 * @version 23-10-21
 */
public class SwitchTest
{
    private Switch sw_true;
    private Switch sw_false;
    
    @BeforeEach
    public void setUp()
    {
        sw_true = new Switch();
        sw_false = new Switch(false);
    }
    
    /*
     * Pruebas del método press en dos situaciones distintas
     * 1- Que el interruptor esté apagado
     * 2- Que el interruptor esté encendido
     */
    
    /*
     * Prueba 1 del método press
     */
    @Test
    public void testPressWithInterruptorActivated(){
        sw_true.press();
        assertEquals(Switch.OFF, sw_true.getInterruptor());
        assertEquals(Switch.OFF, sw_true.getLamp().getStatus());
    }
    
    /*
     * Prueba 2 del método press
     */
    @Test
    public void testPressWithInterruptorDisabled(){
        sw_false.press();
        assertEquals(Switch.ON, sw_false.getInterruptor());
        assertEquals(Switch.ON, sw_false.getLamp().getStatus());
    }
}
