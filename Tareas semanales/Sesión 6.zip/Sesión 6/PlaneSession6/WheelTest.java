

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class WheelTest.
 *
 * @author  Miguel
 * @version 20-10-21 
 */
public class WheelTest
{
    /*
     * Pruebas del constructor sin parámetros
     * Asigna presión estandard y presión máxima estandard
     */
    @Test
    public void testWheelWithoutParams(){
        Wheel wheel1 = new Wheel();
        assertEquals(Wheel.STANDARD_PRESSURE,wheel1.getPressure());
        assertEquals(Wheel.STANDARD_MAX_PRESSURE,wheel1.getMaxPressure());
    }
}
