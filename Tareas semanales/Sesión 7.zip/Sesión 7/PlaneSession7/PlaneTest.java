
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class PlaneTest.
 *
 * @author  Miguel
 * @version 6-10-21
 */
public class PlaneTest
{
    /*
     * Pruebas del constructor por defecto
     * Piloto = null
     * Identificador 'A'
     * Combustible 0
     */
    @Test
    public void testPlaneWithoutParams(){
        Plane plane1 = new Plane(); //el new Plane llama al constructor. con el Plane plane1 creo un objeto llamado plane1 de la clase plane
        assertEquals(Plane.DEFAULT_IDENTIFIER, plane1.getIdentifier());
        assertEquals(Plane.DEFAULT_FUEL, plane1.getFuel());
        assertEquals(Plane.DEFAULT_PILOT, plane1.getPilot());
    }

    /*
     * Pruebas del constructor con parámetro piloto
     * 1- Piloto cualquiera
     * 2- null en lugar de un piloto
     */

    /**
     * 1-Piloto cualquiera
     */
    @Test
    public void testPlaneWithPilot(){
        Person pilot = new Person();     //llamada al constructor
        Plane plane1 = new Plane(pilot); //forma de llamar al constructor con un parámetro
        assertEquals(pilot, plane1.getPilot()); //un assertequals por cada atributo
        assertEquals(Plane.DEFAULT_IDENTIFIER, plane1.getIdentifier());
        assertEquals(Plane.DEFAULT_FUEL,plane1.getFuel());
    }

    /**
     * 2- recibo null
     */
    @Test
    public void testPlaneWithoutPilot(){
        //Person pilot = new Person(); //no necesito piloto al tener éste valor nulo    //llamada al constructor
        Plane plane1 = new Plane(null); //forma de llamar al constructor con un parámetro
        assertEquals(null, plane1.getPilot()); //un assertequals por cada atributo
        assertEquals(Plane.DEFAULT_IDENTIFIER, plane1.getIdentifier());
        assertEquals(Plane.DEFAULT_FUEL,plane1.getFuel());
    }
    
    /**
     * Prueba del constructor Plane con pilot1 como único parámetro
     */
    @Test
    public void testConstructorWithOnlyPilot(){
        Person pilot1 = new Person();
        Plane plane = new Plane(pilot1);
        assertEquals(pilot1,plane.getPilot());
    }
    
    /**
     * Prueba del constructor Plane con Identifier como único parámetro
     */
    @Test
    public void testConstructorWithOnlyIdentifier(){
        Plane plane = new Plane('Z');
        assertEquals('Z',plane.getIdentifier());
    }
    
    /**
     * Prueba del constructor Plane con Fuel como único parámetro
     */
    @Test
    public void testConstructorWithOnlyFuel(){
        Plane plane = new Plane(50);
        assertEquals(50,plane.getFuel());
    }
    
    /*
     * Pruebas del método accelerate con distintas condiciones
     * 1-Que la velocidad tanto de x como de y esté dentro de sus intervalos
     * 2-Que al menos una de las dos velocidades esté por encima del intervalo (velocidad x)
     * 3-Que al menos una de las dos velocidades esté por encima del intervalo (velocidad y)
     * 4-Que al menos una de las dos velocidades esté por debajo del intervalo (velocidad x)
     * 5-Que al menos una de las dos velocidades esté por debajo del intervalo (velocidad y)
     * 6-Que ambas velocidades estén fuera de sus intervalos
     */
    /**
     * Prueba 1 del método accelerate
     * 1-Que la velocidad tanto de x como de y esté dentro de sus intervalos
     */
    @Test
    public void testAccelerateWithCorrectSpeeds(){
        Plane plane1 = new Plane();
        plane1.accelerate(1,1);
        assertEquals(1,plane1.getXSpeed());
        assertEquals(1,plane1.getYSpeed());
    }
    
    /**
     * Prueba 2 del método accelerate
     * 2-Que al menos una de las dos velocidades esté por encima del intervalo (velocidad x)
     */
    @Test
    public void testAccelerateWithHigherXSpeed(){
        Plane plane1 = new Plane();
        try {
            plane1.accelerate(2,1); //Damos uno de los valores incorrectos
            fail("Esperaba salto de excepción");    //Como sabemos que va a fallar, ponemos el fail
        } catch(IllegalArgumentException e){    //Aquí implementaremos el mensaje que saldrá en la excepción a través del assertEquals
            assertEquals ("La velocidad x no es válida",e.getMessage());
        }
    }
    
    /**
     * Prueba 3 del método accelerate
     * 3-Que al menos una de las dos velocidades esté por encima del intervalo (velocidad y)
     */
    @Test
    public void testAccelerateWithHigherYSpeed(){
        Plane plane1 = new Plane();
        try{
            plane1.accelerate(1,2); //Damos uno de los valores incorrectos
            fail("Esperaba salto de excepción");    //Como sabemos que va a saltar un error, ponemos el fail con  el mensaje de la excepción
        } catch(IllegalArgumentException e){    //A través del assertEquals escribiremos el mensaje de la excepción del fallo
            assertEquals("La velocidad y no es válida", e.getMessage());
        }
    }
    
    /**
     * Prueba 4 del método accelerate
     * 4-Que al menos una de las dos velocidades esté por debajo del intervalo (velocidad x)
     */
    @Test
    public void testAccelerateWithLowerXSpeed(){
        Plane plane1 = new Plane();
        try{
            plane1.accelerate(-2,1);    //Damos uno de los valores incorrectos
            fail("Esperaba salto de excepción");    //Como sabemos que la prueba va a fallar, ponemos el fail indicando que saldría un mensaje de excepción
        } catch (IllegalArgumentException e){   //A través del catch, estableceremos el mensaje de excepción usando el assertEquals, en el que dentro de éste pondremos el mensaje comparando con el método getMessage del objeto e
            assertEquals("La velocidad x no es válida", e.getMessage());
        }
    }
    
    /**
     * Prueba 5 del método accelerate
     * 5-Que al menos una de las dos velocidades esté por debajo del intervalo (velocidad y)
     */
    @Test
    public void testAccelerateWithLowerYSpeed(){
        Plane plane1 = new Plane();
         try{
            plane1.accelerate(1,-2);    //Damos uno de los valores incorrectos
            fail("Esperaba salto de excepción");    //Como sabemos que la prueba va a fallar, ponemos el fail indicando que saldría un mensaje de excepción
        } catch (IllegalArgumentException e){   //A través del catch, estableceremos el mensaje de excepción usando el assertEquals, en el que dentro de éste pondremos el mensaje comparando con el método getMessage del objeto e
            assertEquals("La velocidad y no es válida", e.getMessage());
        }
    }
    
    /**
     * Prueba 6 del método accelerate
     * 6-Que ambas velocidades estén fuera de sus intervalos
     */
    @Test
    public void testAccelerateWithIcorrectSpeeds(){
        Plane plane1 = new Plane();
        try{
            plane1.accelerate(-2,-2);   //Damos uno de los valores incorrectos
            fail("Esperaba salto de excepción");    //Como sabemos que la prueba va a fallar, ponemos el fail indicando que saldría un mensaje de excepción
        } catch (IllegalArgumentException e){   //A través del catch, estableceremos el mensaje de excepción usando el assertEquals, en el que dentro de éste pondremos el mensaje comparando con el método getMessage del objeto e
            assertEquals("La velocidad x no es válida",e.getMessage());
        }
    }
}
