

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class NunchukTest.
 *
 * @author  Miguel
 * @version 30-10-21
 */
public class NunchukTest
{
    /*
     * Pruebas del método avanzar con distintos valores de parámetros
     * 1-Parámetro 'R'
     * 2-Parámetro 'L'
     * 3-Parámetro 'U'
     * 4-Parámtero 'D'
     */
    /**
     * Prueba 1 del método avanzar
     * Parámetro 'R'
     */
    @Test
    public void testAvanzarWithParamR(){
        Nunchuk nc1 = new Nunchuk();
        Figure personaje = new Figure();
        personaje.move('R');
        assertEquals(6,personaje.getXPos());
    }
    
    /**
     * Prueba 2 del método avanzar
     * Parámetro 'L'
     */
    @Test
    public void testAvanzarWithParamL(){
        Nunchuk nc1 = new Nunchuk();
        Figure personaje = new Figure();
        personaje.move('L');
        assertEquals(4,personaje.getXPos());
    }
    
    /**
     * Prueba 3 del método avanzar
     * Parámetro 'U'
     */
    @Test
    public void testAvanzarWithParamU(){
        Nunchuk nc1 = new Nunchuk();
        Figure personaje = new Figure();
        personaje.move('U');
        assertEquals(6,personaje.getYPos());
    }
    
    /**
     * Prueba 4 del método avanzar
     * Parámetro 'D'
     */
    @Test
    public void testAvanzarWithParamD(){
        Nunchuk nc1 = new Nunchuk();
        Figure personaje = new Figure();
        personaje.move('D');
        assertEquals(4,personaje.getYPos());
    }
    
    /*
     * Pruebas del método midleAdvance con distintos parámetros
     * 1-Parámetro 'R'
     * 2-Parámetro 'L'
     * 3-Parámetro 'U'
     * 4-Parámtero 'D'
     */
    /**
     * Prueba 1 del método midleAdvance
     * Parámetro 'R'
     */
    @Test
    public void testMidleAdvanceWithParamR(){
        Nunchuk nc1 = new Nunchuk();
        Figure personaje = new Figure();
        personaje.move('R');
        personaje.move('R');
        assertEquals(7,personaje.getXPos());
    }
    
    /**
     * Prueba 2 del método midleAdvance
     * Parámetro 'L'
     */
    @Test
    public void testMidleAdvanceWithParamL(){
        Nunchuk nc1 = new Nunchuk();
        Figure personaje = new Figure();
        personaje.move('L');
        personaje.move('L');
        assertEquals(3,personaje.getXPos());
    }
    
    /**
     * Prueba 3 del método midleAdvance
     * Parámetro 'U'
     */
    @Test
    public void testMidleAdvanceWithParamU(){
        Nunchuk nc1 = new Nunchuk();
        Figure personaje = new Figure();
        personaje.move('U');
        personaje.move('U');
        assertEquals(7,personaje.getYPos());
    }
    
    /**
     * Prueba 4 del método midleAdvance
     * Parámetro 'D'
     */
    @Test
    public void testMidleAdvanceWithParamD(){
        Nunchuk nc1 = new Nunchuk();
        Figure personaje = new Figure();
        personaje.move('D');
        personaje.move('D');
        assertEquals(3,personaje.getYPos());
    }
    
    /*
     * Pruebas del método muchAdvance con distintos parámetros
     * 1-Parámetro 'R'
     * 2-Parámetro 'L'
     * 3-Parámetro 'U'
     * 4-Parámtero 'D'
     */
    /**
     * Prueba 1 del método muchAdvance
     * Parámetro 'R'
     */
    @Test
    public void testMuchAdvanceWithParamR(){
        Nunchuk nc1 = new Nunchuk();
        Figure personaje = new Figure();
        personaje.move('R');
        personaje.move('R');
        personaje.move('R');
        personaje.move('R');
        personaje.move('R');
        assertEquals(10,personaje.getXPos());
    }
    
    /**
     * Prueba 2 del método muchAdvance
     * Parámetro 'L'
     */
    @Test
    public void testMuchAdvanceWithParamL(){
        Nunchuk nc1 = new Nunchuk();
        Figure personaje = new Figure();
        personaje.move('L');
        personaje.move('L');
        personaje.move('L');
        personaje.move('L');
        personaje.move('L');
        assertEquals(0,personaje.getXPos());
    }
    
    /**
     * Prueba 3 del método muchAdvance
     * Parámetro 'U'
     */
    @Test
    public void testMuchAdvanceWithParamU(){
        Nunchuk nc1 = new Nunchuk();
        Figure personaje = new Figure();
        personaje.move('U');
        personaje.move('U');
        personaje.move('U');
        personaje.move('U');
        personaje.move('U');
        assertEquals(10,personaje.getYPos());
    }
    
    /**
     * Prueba 4 del método muchAdvance
     * Parámetro 'D'
     */
    @Test
    public void testMuchAdvanceWithParamD(){
        Nunchuk nc1 = new Nunchuk();
        Figure personaje = new Figure();
        personaje.move('D');
        personaje.move('D');
        personaje.move('D');
        personaje.move('D');
        personaje.move('D');
        assertEquals(0,personaje.getYPos());
    }
    
    /*
     * Pruebas del método shootForward con distintos parámetros
     * 1-Parámetro 'R'
     * 2-Parámetro 'L'
     * 3-Parámetro 'U'
     * 4-Parámtero 'D'
     */
    /**
     * Prueba 1 del método shootForward
     * Parámetro 'R'
     */
    @Test
    public void testShootForwardWithParamR(){
        Nunchuk nc1 = new Nunchuk();
        Figure personaje = new Figure();
        Weapon weapon = new Weapon();
        personaje.move('R');
        weapon.shoot();
        assertEquals(6,personaje.getXPos());
        assertEquals(46,weapon.getAmmunition());
    }
    
    /**
     * Prueba 2 del método shootForward
     * Parámetro 'L'
     */
    @Test
    public void testShootForwardWithParamL(){
        Nunchuk nc1 = new Nunchuk();
        Figure personaje = new Figure();
        Weapon weapon = new Weapon();
        personaje.move('L');
        weapon.shoot();
        assertEquals(4,personaje.getXPos());
        assertEquals(46,weapon.getAmmunition());
    }
    
    /**
     * Prueba 3 del método shootForward
     * Parámetro 'U'
     */
    @Test
    public void testShootForwardWithParamU(){
        Nunchuk nc1 = new Nunchuk();
        Figure personaje = new Figure();
        Weapon weapon = new Weapon();
        personaje.move('U');
        weapon.shoot();
        assertEquals(6,personaje.getYPos());
        assertEquals(46,weapon.getAmmunition());
    }
    
    /**
     * Prueba 4 del método shootForward
     * Parámetro 'D'
     */
    @Test
    public void testShootForwardWithParamD(){
        Nunchuk nc1 = new Nunchuk();
        Figure personaje = new Figure();
        Weapon weapon = new Weapon();
        personaje.move('D');
        weapon.shoot();
        assertEquals(4,personaje.getYPos());
        assertEquals(46,weapon.getAmmunition());
    }
}
