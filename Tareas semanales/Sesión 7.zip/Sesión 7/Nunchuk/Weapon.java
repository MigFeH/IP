
/**
 * La clase Weapon describe un arma
 * 
 * @author Miguel
 * @version 30-10-21
 */
public class Weapon
{    
    // instance variables
    private String name;    //Nombre del arma
    private int ammunition; //Cantidad de munición

    /**
     * Constructor de la clase Weapon sin parámetros
     */
    public Weapon()
    {
        setName("AK-47");
        setAmmunition(47);
    }

    /**
     * Constructor de la clase Weapon con name y ammunition como parámetros
     */
    public Weapon(String name, int ammunition)
    {
        setName(name);
        setAmmunition(ammunition);
    }

    /**
     * Modifica el valor del atributo name
     * 
     * @param el nuevo nombre
     */
    private void setName(String name)
    {
        this.name = name;
    }

    /**
     * Retorna el valor del atributo name
     * 
     * @return name
     */
    public String getName()
    {
        return name;
    }

    /**
     * Modifica el valor del atributo ammunition
     * 
     * @param la nueva cantidad de munición
     */
    private void setAmmunition(int ammunition)
    {
        this.ammunition = ammunition;
    }

    /**
     * Retorna el valor del atributo ammunition
     * 
     * @return la cantidad de munición
     */
    public int getAmmunition()
    {
        return ammunition;
    }

    /**
     * El método shoot (disparar) realizará lo siguiente: 
     * Si tiene munición imprime por pantalla “BANG” y
     * disminuye una unidad la munición. Si no tiene munición no hace nada.
     */
    public void shoot()
    {
        if (getAmmunition() > 0){
            System.out.println("BANG");
            setAmmunition(getAmmunition()-1);
        }
    }

    /**
     * Método toString devuelve una cadena 
     * con el nombre del arma y la munición total que tiene.
     *
     * @return la cadena del toString
     */
    public String toString()
    {
        String data = getName() + getAmmunition();
        return data;
    }
}
