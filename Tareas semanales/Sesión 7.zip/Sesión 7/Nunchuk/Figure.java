
/**
 * Clase Figure describe un personaje
 * 
 * @author Miguel
 * @version 30-10-21
 */
public class Figure
{
    //Costantes:
    public static final int X_LOWER_EDGE = 0;    //Coordenada x de los bordes inferiores 
    public static final int Y_LOWER_EDGE = 0;    //Coordenada y de los bordes inferiores

    public static final int X_UPPER_EDGE = 640;    //Coordenada x de los bordes superiores
    public static final int Y_UPPER_EDGE = 320;    //Coordenada y de los bordes superiores 

    public static final char LEFT = 'L';    //Movimiento hacia la izquierda
    public static final char RIGHT = 'R';    //Movimiento hacia la derecha
    public static final char UP = 'U';    //Movimiento hacia arriba
    public static final char DOWN = 'D';    //Movimiento hacia abajo

    public static final int STEP = 10;  //Distancia en pixels

    // instance variables:
    private String name;    //Nombre del personaje
    private int xPos;       //Posición x del personaje
    private int yPos;       //Posición y del personaje

    /**
     * Constructor de la clase Figure sin parámetros
     */
    public Figure()
    {
        setName("Miguel");
        setXPos(5);
        setYPos(5);
    }

    /**
     * Constructor de la clase Figure con name como parámetro
     */
    public Figure(String name)
    {
        this();
        setName(name);
    }

    /**
     * El método setName modificará el valor del atributo name
     * 
     * @param el nuevo nombre
     */
    private void setName(String name)
    {
        this.name = name;
    }

    /**
     * El método getName retorna el valor de name
     * 
     * @return name
     */
    public String getName()
    {
        return name;
    }

    /**
     * El método setXPos modificará el valor del atributo xPos
     * 
     * @param nueva xPos
     */
    private void setXPos(int xPos)
    {
        this.xPos = xPos;
    }

    /**
     * El método getXPos retorna el valor de xPos
     * 
     * @return xPos
     */
    public int getXPos()
    {
        return xPos;
    }

    /**
     * El método setYPos modificará el valor del atributo yPos
     * 
     * @param nueva yPos
     */
    private void setYPos(int yPos)
    {
        this.yPos = yPos;
    }

    /**
     * El método getYPos retorna el valor de yPos
     * 
     * @return yPos
     */
    public int getYPos()
    {
        return yPos;
    }

    /**
     * El método move indica la dirección de movimiento del
     * personaje. 
     * 
     * Si recibe LEFT o RIGHT se mueve un paso adelante o atrás en el eje X 
     * Si recibe UP o DOWN se mueve un paso arriba o abajo en el eje Y.
     * Si al moverse se pasa del borde de la pantalla
     * no se ejecuta el movimiento (no cambia la posición).
     *
     * @param la dirección de movimiento
     * 
     */
    public void move(char move)
    {
        if ((move == LEFT) && (getXPos() > X_LOWER_EDGE)){
            setXPos(getXPos()-1);
        }
        if ((move == RIGHT) && (getXPos() < X_UPPER_EDGE)){
            setXPos(getXPos()+1);
        }if ((move == UP) && (getYPos() < Y_UPPER_EDGE)){
            setYPos(getYPos()+1);
        }if ((move == DOWN) && (getYPos() > Y_LOWER_EDGE)){
            setYPos(getYPos()-1);
        }
    }
    
    /**
     * El método toString devuelve una cadena con el nombre del personaje
     * y su posición X e Y
     * 
     * @return la cadena con el nombre del personaje y su posición X e Y
     */
    public String toString(){
        String data = (getName() + "(" + getXPos() + "," + 
                        getYPos() + ")");
        return data;           
    }
}