

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class WeaponTest.
 *
 * @author  Miguel
 * @version 30-10-21
 */
public class WeaponTest
{
    /*
     * Pruebas del constructor sin parámetros
     */
    @Test
    public void testConstructorWithoutParams(){
        Weapon weapon = new Weapon();
        assertEquals("AK-47",weapon.getName());
        assertEquals(47,weapon.getAmmunition());
    }
    
    /*
     * Pruebas del método shoot en dos situcaciones distintas
     * 1-Que el arma tenga suficiente munición
     * 2-Que el arma no tenga munición
     */
    /**
     * Prueba 1 del método shoot
     * Que el arma tenga suficiente munición
     */
    @Test
    public void testShootWithEnoughAmmunition(){
        Weapon weapon = new Weapon();
        weapon.shoot();
        assertEquals(46,weapon.getAmmunition());
    }
    
    /**
     * Prueba 2 del método shoot
     * Que el arma no tenga munición
     */
    @Test
    public void testShootWithoutAmmunition(){
        Weapon weapon = new Weapon("AK-47",0);
        weapon.shoot();
        assertEquals(0,weapon.getAmmunition());
    }
}
