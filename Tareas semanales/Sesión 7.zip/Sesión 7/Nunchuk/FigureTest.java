

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class FigureTest.
 *
 * @author  Miguel
 * @version 30-10-21
 */
public class FigureTest
{
    /*
     * Prueba del constructor sin parámetros
     */
    @Test
    public void testConstructorWithoutParams(){
        Figure personaje = new Figure();
        assertEquals("Miguel",personaje.getName());
        assertEquals(5,personaje.getXPos());
        assertEquals(5,personaje.getYPos());
    }
    
    /*
     * Pruebas del método move con distintos parámetros
     * 1-Parámetro 'L'
     * 2-Parámetro 'R'
     * 3-Parámetro 'U'
     * 4-Parámetro 'D'
     */
    /**
     * Prueba 1 del método move
     * Parámetro 'L'
     */
    @Test
    public void testMoveWithParamL(){
        Figure personaje = new Figure();
        personaje.move('L');
        assertEquals(4,personaje.getXPos());
    }
    
    /**
     * Prueba 2 del método move
     * Parámetro 'R'
     */
    @Test
    public void testMoveWithParamR(){
        Figure personaje = new Figure();
        personaje.move('R');
        assertEquals(6,personaje.getXPos());
    }
    
    /**
     * Prueba 3 del método move
     * Parámetro 'U'
     */
    @Test
    public void testMoveWithParamU(){
        Figure personaje = new Figure();
        personaje.move('U');
        assertEquals(6,personaje.getYPos());
    }
    
    /**
     * Prueba 4 del método move
     * Parámetro 'D'
     */
    @Test
    public void testMoveWithParamD(){
        Figure personaje = new Figure();
        personaje.move('D');
        assertEquals(4,personaje.getYPos());
    }
}
