
/**
 * La clase Nunchuk simula un mando que controla un personaje con un arma
 * 
 * @author Miguel
 * @version 30-10-21
 */
public class Nunchuk
{
    // instance variables 
    private Figure personaje;   //Personaje de la clase Figure
    private Weapon weapon;      //Arma de la clase Weapon

    /**
     * Constructor de la clase Nunchuk sin parámetros
     */
    public Nunchuk()
    {
        Figure personaje = new Figure();
        Weapon weapon = new Weapon();
    }

    /**
     * Constructor de la clase Nunchuk con parámetros
     */
    public Nunchuk(String name, String arma, int ammunition)
    {
        Figure personaje = new Figure(name);
        Weapon weapon = new Weapon(arma,ammunition);
    }

    /**
     * Método avanzar
     * Desplazará un paso al personaje
     * 
     * @param dirección del movimiento
     */
    public void avanzar(char direction)
    {
        Figure personaje = new Figure();
        if (direction == 'U'){
            personaje.move(Figure.UP);
        }
        if (direction == 'D'){
            personaje.move('D');
        }
        if (direction == 'R'){
            personaje.move('R');
        }
        if (direction == 'L'){
            personaje.move('L');
        }
    }

    /**
     * Método midleAdvance (avanzar medio)
     * Desplazará dos pasos al personaje
     * 
     * @param dirección del movimiento
     */
    public void midleAdvance(char direction)
    {
        Figure personaje = new Figure();
        if (direction == 'U'){
            personaje.move('U');
            personaje.move('U');
        }
        if (direction == 'D'){
            personaje.move('D');
            personaje.move('D');
        }
        if (direction == 'R'){
            personaje.move('R');
            personaje.move('R');
        }
        if (direction == 'L'){
            personaje.move('L');
            personaje.move('L');
        }
    }

    /**
     * Método muchAdvance (avanzar mucho)
     * Desplazará cinco pasos al personaje
     * 
     * @param dirección del movimiento
     */
    public void muchAdvance(char direction)
    {
        Figure personaje = new Figure();
        if (direction == 'U'){
            personaje.move('U');
            personaje.move('U');
            personaje.move('U');
            personaje.move('U');
            personaje.move('U');
        }
        if (direction == 'D'){
            personaje.move('D');
            personaje.move('D');
            personaje.move('D');
            personaje.move('D');
            personaje.move('D');
        }
        if (direction == 'R'){
            personaje.move('R');
            personaje.move('R');
            personaje.move('R');
            personaje.move('R');
            personaje.move('R');
        }
        if (direction == 'L'){
            personaje.move('L');
            personaje.move('L');
            personaje.move('L');
            personaje.move('L');
            personaje.move('L');
        }
    }

    /**
     * El método shootWeapon (disparar arma).
     * 
     * Tiene como parámetro un valor booleano que indica: 
     * false si el arma se dispara una vez, 
     * true si el arma se dispara 5 veces (ráfaga)
     *
     * @param modo de disparo 
     */
    public void shootWeapon(boolean shootmode)
    {
        Weapon weapon = new Weapon();
        if (shootmode == true){
            weapon.shoot();
            weapon.shoot();
            weapon.shoot();
            weapon.shoot();
            weapon.shoot();
        } else{
            weapon.shoot();
        }
    }

    /**
     * El método shootForward (disparar avanzar). 
     * Tiene como parámetro la dirección hacia donde se debe desplazar 
     * el personaje. 
     * El personaje se moverá y disparará una vez.
     * 
     * @param la dirección hacia donde se debe desplazar el personaje
     */
    public void shootForward(char direction){
        Figure personaje = new Figure();
        Weapon weapon = new Weapon();
        if (direction == 'U'){
            personaje.move('U');
            weapon.shoot();
        }
        if (direction == 'D'){
            personaje.move('D');
            weapon.shoot();
        }
        if (direction == 'R'){
            personaje.move('R');
            weapon.shoot();
        }
        if (direction == 'L'){
            personaje.move('L');
            weapon.shoot();
        }
    }

    /**
     * El método print imprime el estado de los atributos
     */
    public void print()
    {
        System.out.println(personaje.toString() + weapon.toString());
    }
}
