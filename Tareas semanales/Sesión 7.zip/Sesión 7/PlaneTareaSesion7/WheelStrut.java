
/**
 * Puntal para sujetar dos ruedas
 * Contiene valor para indicar si está o no desplegado
 * 
 * @author Miguel 
 * @version 27-10-21
 */
public class WheelStrut
{
    //Constantes
    public static final double BOEING_737_PRESSURE = 1739; //Mb de presión
    public static final boolean IS_DEPLOYED = true;

    // instance variables
    private boolean deployed;
    private Wheel leftWheel;
    private Wheel rightWheel;

    /**
     * Constructor de la clase WheelStrut sin parámetros
     */
    public WheelStrut()
    {
        setDeployed(IS_DEPLOYED);
        setLeftWheel(new Wheel(BOEING_737_PRESSURE, BOEING_737_PRESSURE));
        setRightWheel(new Wheel(BOEING_737_PRESSURE, BOEING_737_PRESSURE));
    }

    /**
     * Constructor de la clase WheelStrut con las ruedas como parámetros
     */
    public WheelStrut(Wheel leftWheel, Wheel rightWheel)
    {
        this();
        setLeftWheel(leftWheel);
        setRightWheel(rightWheel);
    }

    /**
     * Asigna valor al atributo deployed
     * 
     * @param deployed true si está desplegado
     */
    private void setDeployed(boolean deployed)
    {
        this.deployed = deployed;
    }

    /**
     * Retorna el valor del atributo deployed
     * 
     * @return el valor de deployed
     */
    public boolean isDeployed() //Al ser booleano, en vez de poner get, ponemos is
    {
        return deployed;
    }

    /**
     * Asigna valor al atributo leftWheel
     * 
     * @param left rueda izquierda
     */
    private void setLeftWheel(Wheel left)
    {
        checkParam(left != null,"null en lugar de rueda izquierda");
        //checkParam(left.test(), "La rueda no está suficientemente hinchada");
        leftWheel = left;
    }

    /**
     * Asigna valor al atributo rightWheel
     * 
     * @param right rueda derecha
     */
    private void setRightWheel(Wheel right)
    {
        checkParam(right != null,"null en lugar de rueda derecha");
        //checkParam(right.test(), "La rueda no está suficientemente hinchada");
        rightWheel = right;
    }

    /**
     * @return valor de leftWheel
     */
    public Wheel getLeftWheel(){
        return leftWheel;
    }

    /**
     * @return valor de rightWheel
     */
    public Wheel getRightWheel(){
        return rightWheel;
    }

    /**
     * Método que comprueba si ambas ruedas están operativas
     * (ambas pasan sus test)
     * @return retorna true si el puntal está operativo y false si no lo está
     */
    public boolean test(){
        // if (leftWheel.test() && rightWheel.test()){
        // return true;
        // } else{
        // return false;
        // }

        //Alternativa:
        return leftWheel.test() && rightWheel.test();
    }

    /**
     * El método print imprimirá:
     * El valor de la propiedad deployed
     * El valor de retorno del método test()
     * El resultado de la ejecución del método print() sobre cada rueda.
     *
     * Con un aspecto final como el que sigue:
     * 
     * RETRACTED (o DEPLOYED)
     * Test............... FALSE.
     *
     * LEFT Wheel
     * Max Pressure....... 34500,0 Mb.
     * Current Pressure... 32000,0 Mb (92,75%)
     * Test............... OK (FAIL, si falló el test).
     * 
     * RIGHT Wheel
     * Max Pressure....... 34500,0 Mb.
     * Current Pressure... 5205,0 Mb (15,08%)
     * Test............... OK (FAIL, si falló el test).
     *
     */
    public void print()
    {        
        System.out.println("IS DEPLOYED?: "+ isDeployed());
        System.out.println("Test..............." + test());
        System.out.println();
        
        System.out.println("LEFT Wheel");
        System.out.println(String.format("Max Pressure....... %.1f Mb", leftWheel.getMaxPressure()));
        System.out.println(String.format("Current Pressure... %.1f Mb (%.2f)",leftWheel.getPressure(), leftWheel.getPercentage()));
        System.out.println(String.format("Test............... %s",leftWheel.test()));
        System.out.println();
        
        System.out.println("RIGHT Wheel");
        System.out.println(String.format("Max Pressure....... %.1f Mb", rightWheel.getMaxPressure()));
        System.out.println(String.format("Current Pressure... %.1f Mb (%.2f)",rightWheel.getPressure(), leftWheel.getPercentage()));
        System.out.println(String.format("Test............... %s",rightWheel.test()));
        
    }
    
     /**
     * Validación de parámetro. Salta excepción si no cumple parámetro
     * @param la condición
     * @param mensaje si no cumple condición
     */
    private void checkParam(boolean condition, String msg){
        if (!condition){
            throw new IllegalArgumentException(msg);
        }
    }
}
