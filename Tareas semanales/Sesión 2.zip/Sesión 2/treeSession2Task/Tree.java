
/**
 * Write a description of class Tree here.
 * 
 * @author (Miguel) 
 * @version (22/09/2021)
 */
public class Tree
{
    // instance variables
    private String typeOfTree;      //tipo de árbol, como un manzano o un peral
    private int maxNumberOfFlowers; //máximo número de flores del árbol
    private int numberOfFlowers;    //número de flores del árbol
    private int numberOfFruits;     //número de frutas del árbol

    /**
     * Constructor for objects of class Tree
     */
    public Tree()
    {
        String typeOfTree = "Manzano";
        int maxNumberOfFlowers = 25;
        int numberOfFlowers = 7;
        int numberOfFruits = 3;
    }

    /**
     * Modifica el valor del atributo typeOfTree
     * 
     * @param  newTypeOfTree nuevo valor para typeOfTree
     * 
     */
    public void setTypeOfTree(String newTypeOfTree)
    {
        typeOfTree = newTypeOfTree;
    }

    /**
     * Modifica el valor del atributo numberOfFlowers
     * 
     * @param  newNumberOfFlowers nuevo valor para numberOfFlowers
     * 
     */
    public void setNumberOfFlowers(int newNumberOfFlowers)
    {
        checkParam(newNumberOfFlowers <= maxNumberOfFlowers);
        checkParam2(newNumberOfFlowers >= 0);
        numberOfFlowers = newNumberOfFlowers;
    }
    
    /**
     * Modifica el valor del atributo maxNumberOfFlowers
     * 
     * @param  newMaxNumberOfFlowers nuevo valor para MaxNumberOfFlowers
     * 
     */
    public void setMaxNumberOfFlowers(int newMaxNumberOfFlowers)
    {
        checkParam4(newMaxNumberOfFlowers >= numberOfFlowers);
        checkParam5(newMaxNumberOfFlowers >=0);
        maxNumberOfFlowers = newMaxNumberOfFlowers;
    }

    /**
     * Modifica el valor del atributo numberOfFruits
     * 
     * @param  newNumberOfFruits nuevo valor para numberOfFruits
     * 
     */
    public void setNumberOfFruits(int newNumberOfFruits)
    {
        checkParam3(newNumberOfFruits >=0);
        numberOfFruits = newNumberOfFruits;
    }

    /**
     * Comprueba si la condición es correcta. Si no lo es, lanza excepción
     *
     * @param condition condición a comprobar
     *
     */
    private void checkParam(boolean condition)
    {
        if (! condition) {
            throw new IllegalArgumentException("El número de flores no puede exceder el número máximo de estas");
        }
    }
    
    /**
     * Comprueba si la condición es correcta. Si no lo es, lanza excepción
     *
     * @param condition condición a comprobar
     *
     */
    private void checkParam4(boolean condition)
    {
        if (! condition) {
            throw new IllegalArgumentException("El número máximo de flores no puede ser inferior al número de flores que ya tiene el árbol");
        }
    }
    
    /**
     * Comprueba si la condición es correcta. Si no lo es, lanza excepción
     *
     * @param condition condición a comprobar
     *
     */
    private void checkParam5(boolean condition)
    {
        if (! condition) {
            throw new IllegalArgumentException("El número máximo de flores no puede ser negativo");
        }
    }

    /**
     * Comprueba si la condición es correcta. Si no lo es, lanza excepción
     *
     * @param condition2 condición a comprobar
     *
     */
    private void checkParam2(boolean condition)
    {
        if (! condition) {
            throw new IllegalArgumentException("El número de flores no puede negativo");
        }
    }

    /**
     * Comprueba si la condición es correcta. Si no lo es, lanza excepción
     *
     * @param condition condición a comprobar
     *
     */
    private void checkParam3(boolean condition)
    {
        if (! condition) {
            throw new IllegalArgumentException("El número de frutas no puede ser negativo");
        }
    }

    /**
     * Devuelve el valor del atributo typeOfTree
     *
     *
     * @return     el valor del atributo typeOfTree, de tipo String
     */
    public String getTypeOfTree()
    {
        return typeOfTree;
    }

    /**
     * Devuelve el valor del atributo numberOfFlowers
     *
     *
     * @return     el valor del atributo numberOfFlowers, de tipo int
     */
    public int getNumberOfFlowers()
    {
        return numberOfFlowers;
    }

    /**
     * Devuelve el valor del atributo maxNumberOfFlowers
     *
     *
     * @return     el valor del atributo maxNumberOfFlowers, de tipo int
     */
    public int getMaxNumberOfFlowers()
    {
        return maxNumberOfFlowers;
    }

    /**
     * Devuelve el valor del atributo numberOfFruits
     *
     *
     * @return     el valor del atributo numberOfFruits, de tipo int
     */
    public int getNumberOfFruits()
    {
        return numberOfFruits;
    }

    /**
     * Devuelve los datos del árbol con el siguiente formato:
     * tipo de árbol-ńumero máximo de flores-número de flores-número de frutas
     * EJEMPLO
     * Manzano-25-7-3
     *
     * 
     * @return     cadena de datos del árbol en el formato anterior
     */
    public String toString()
    {
        String result = getTypeOfTree() + "-" + getMaxNumberOfFlowers () + "-" + getNumberOfFlowers () + "-" + getNumberOfFruits();
        return result;
    }

    /**
     * Imprime por pantalla los valores de las propiedades del objeto árbol 
     * con el siguiente formato:
     * "Valores de las propiedades del árbol: Manzano-25-7-3"
     * Siendo respectivamente el tipo de árbol, número máximo de flores, número de flores
     * y número de frutas
     *
     *
     */
    public void print ()
    {
        System.out.println("Valores de las propiedades del árbol: " + getTypeOfTree() + "-" + getMaxNumberOfFlowers() + "-" + getNumberOfFlowers() + "-" + getNumberOfFruits() );
    }
}
