
/**
 * Clase Person define una persona con nombre y edad.
 * Se define los métodos set y get para cada atributo
 *Para la sesión 1
 * 
 * @author (Miguel) 
 * @version 15-9-2021
 */
public class Person
{

    private String name;        //nombre de la persona
    private int age;
    private String surname;
    private boolean gender;

    /**
     * Constructor for objects of class Person
     */
    public Person()
    {
        //name = "Miguel";
        setName("Miguel");
        //age = 35;
        setAge (35);
    }

    /**
     * Modifica el valor del atributo name
     * 
     * @param  newName   nuevo valor para name
     *
     */
    public void setName(String newName)
    {
        name = newName; 
    }

    /**
     * Devuelve el valor del atributo name
     *
     * 
     * @return     el valor del atributo name, de tipo String
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * Modifica el valor del atributo age
     * 
     * @param  newAge   nuevo valor para age
     *
     */
    public void setAge(int newAge)
    {
        age = newAge;
    }
    
    /**
     * Devuelve el valor del atributo age
     *
     * 
     * @return     el valor del atributo age, de tipo int
     */
    public int getAge()
    {
        return age;
    }
    
    /**
     * Modifica el valor del atributo surname
     * 
     * @param  newSurname nuevo valor para surname, de tipo String
     *
     */
    public void setSurname(String newSurname)
    {
        surname = newSurname;
    }
    
    /**
     * Devuelve el valor del atributo surname 
     *
     * 
     * @return     el valor del atributo surname, de tipo String
     */
    public String getSurname()
    {
        return surname;
    }
    
    /**
     * Modifica el valor del atributo gender
     * 
     * @param  newGender nuevo valor para gender, de tipo boolean
     *
     */
    public void setGender (boolean newGender)
    {
        gender = true;
        gender = false;
    }
    
    /**
     * Devuelve el valor del atributo gender 
     *
     * 
     * @return     el valor del atributo gender, de tipo boolean
     */
    public boolean getGender()
    {
        return gender;
    }
}
