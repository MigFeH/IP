
/**
 * Write a description of class Bus here.
 * 
 * @author Miguel 
 * @version 9-10-21
 */
public class Bus
{
    //constantes
    public static final int MAX_NUMBER_OF_SEATS=60;    //El número maximo de asientos del autobús

    // instance variables
    private boolean driverPresent;  /*Indicará la presencia del conductor en el autobús.
    Un valor true cuando esté en el bus y un valor false para cuando no */

    private int availableSeats;     //Almacena un número entero de asientos libres.                                
    /**
     * Constructor for objects of class Bus
     */
    public Bus()
    {
        driverPresent=false;    //no hay conductor
        availableSeats=MAX_NUMBER_OF_SEATS; //todos los asientos están ocupados
    }

    /**
     * Constructor for objects of class Bus
     */
    public Bus(boolean driverPresent,int availableSeats)
    {
        this.driverPresent=driverPresent;
        this.availableSeats=availableSeats;
    }

    /**
     * El método sitDriver modifica el valor del atributo driverPresent a true
     *
     */
    public void sitDriver()
    {
        driverPresent=true;
    }

    /**
     * Devuelve el valor del atributo driverPresent
     *
     * @return true o false
     */
    public boolean getDriverPresent()
    {
        return driverPresent; //devuelve el atributo
    }

    /**
     * Asigna el valor del atributo driverPresent de tipo boolean
     * 
     */
    private void setDriverPresent(boolean driverPresent)
    {
        this.driverPresent=driverPresent;
    }

    /**
     * Devuelve el valor del atributo availableSeats
     *
     * @return el número de asientos disponibles
     */
    public int getAvailableSeats()
    {
        return availableSeats; //devuelve el atributo
    }

    /**
     * Asigna el valor del atributo availableSeats de tipo int
     * 
     */
    private void setAvailableSeats(int availableSeats)
    {
        this.availableSeats=availableSeats;
    }

    /**
     * El método getOn recibe como parámetro el número de pasajeros que quieren
     * subirse al autobús. Si el conductor está en el autobús y hay sitio
     * suficiente para todos los pasajeros, decrementa el número de asientos
     * libres en una cantidad igual a la del número de pasajeros y retorna un
     * valor true. En caso contrario, no entrará ningún pasajero y retorna
     * false.
     * 
     * @param el atributo availableSeats
     * return valores true o flase
     */
    public boolean getOn(int numberOfPeople)
    {
        if(driverPresent==true && availableSeats<=MAX_NUMBER_OF_SEATS){
            setAvailableSeats(getAvailableSeats()-numberOfPeople);
            return true;
        } else{
            return false;
        }
    }

    /**
     * El método toString devuelve una cadena que contiene la siguiente información
     * separada por guiones:
     * “ON DUTY”, si el conductor está en el autobús o “OUT OF SERVICE”, si no lo está.
     * Guión “-“ El número de asientos disponibles. 
     *
     * @return el toString
     */
    public String toString()
    {
        String toString;
        if(driverPresent==true){
            toString="ON DUTY";
            return toString+"-"+availableSeats;
        }else{
            toString="OUT OF SERVICE";
            return toString;
        }
    }
}