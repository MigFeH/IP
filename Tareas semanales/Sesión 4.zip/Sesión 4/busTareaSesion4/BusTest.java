

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class BusTest.
 *
 * @author  Miguel
 * @version 9-10-21
 */
public class BusTest
{
    /*
     * Prueba para el constructor sin parámetros bus
     */
    @Test
    public void testBusWithoutParams()
    {
        Bus bus1=new Bus();
    }
    
    /*
     * Prueba para el constructor bus con los parámetros boolean e int
     */
    @Test
    public void testBusWithParams()
    {
        Bus bus1=new Bus(false,46);
    }
    
    /*
     * Prueba para el método sitDriver
     */
    @Test
    public void testSitDriver()
    {
        Bus bus1=new Bus();
        bus1.sitDriver();
        assertEquals(true,bus1.getDriverPresent());
    }
    
    /*
     * Prueba para el método getOn
     */
    @Test
    public void testGetOn()
    {
        Bus bus1=new Bus();
        bus1.sitDriver();
        bus1.getOn(20);
        assertEquals(true,bus1.getOn(20));
    }
    
    /*
     * Prueba para el método toString
     */
    @Test
    public void testToStringWithDriver()
    {
        Bus bus1=new Bus();
        bus1.getAvailableSeats();
        bus1.sitDriver();
        assertEquals("ON DUTY-"+bus1.getAvailableSeats(),bus1.toString());
    }
    
    /*
     * Prueba para el método toString
     */
    @Test
    public void testToStringWithoutDriver()
    {
        Bus bus1=new Bus();
        bus1.getAvailableSeats();
        assertEquals("OUT OF SERVICE",bus1.toString());
    }
}
