
/**
 * Clase Plane, describe un avión con piloto, identificador 
 * y combustible que podrá volar
 * 
 * @author Miguel 
 * @version 6-10-21
 */
public class Plane
{
    public static final int MIN_FUEL = 0;
    public static final int MAX_FUEL = 5000;
    
    public static final Person DEFAULT_PILOT = null;
    public static final char DEFAULT_IDENTIFIER = 'A';
    public static final int DEFAULT_FUEL = 0;
    
    private Person pilot;       //piloto para el avión 
                                //atributos en privado
                                
    private char identifier;    //identificador para el avión entre 'A' y 'Z'
                                //el char sirve para referenciar un único carácter
                                
    private int fuel;           //combustible para el avión [0,5000]
    
    /**
     * Constructor for objects of class Plane
     */
    public Plane()
    {
        setPilot(DEFAULT_PILOT);
        setIdentifier(DEFAULT_IDENTIFIER);
        setFuel(DEFAULT_FUEL);
        
    }
    
    /**
     * Constructor de la clase Plane con solo identificador como único parámetro
     */
    public Plane(char identifier)
    {
        setIdentifier(identifier); //valor de identificador default
    }
    
    /**
     * Constructor de la clase Plane con solo pilot (de la clase person) como único parámetro
     */
    public Plane(Person pilot1)
    {
        setPilot(pilot1); //valor de piloto default
    }
    
    /**
     * Constructor de la clase Plane con solo fuel como único parámetro
     */
    public Plane(int fuel)
    {
        setFuel(fuel); //valor de fuel default
    }
    
    
    // /**
     // * todos los valores por defecto excepto el piloto
     // * @param pilot piloto para el avión
     // */
    // public Plane(Person pilot) {
        // this(); //con el this ejecutamos el setidentifier y el setfuel del constructor plane al ser en ambos metodos comunes
        // setPilot(pilot); //y al ser el pilot el único distinto del constructor del plane, cambiamos su estado
        
    // }
    
    /**
     * Modifica el valor del atributo pilot
     * 
     * @param  pilot, nuevo piloto para el avión 
     * 
     */
    private void setPilot(Person pilot)   //los set no devuelven nada
                                        //ahora los set serán métodos pivados a menos que nos pidan lo contrario
                                        //el parámetro es un objeto de otra clase
    {
        //checkParam(pilot != null, "Se ha recibido null"); //comprobación de que pilot tiene un nombre distinto de null
        this.pilot = pilot; 
    }
    
    private void checkParam(boolean condition, String msg) {
        if (! condition) {
            throw new IllegalArgumentException(msg);
        }
    }
    
    /**
     * Modifica el valor del atributo identifier
     * 
     * @param  identifier, nuevo identificador entre 'A' y 'Z' 
     * 
     */
    private void setIdentifier(char identifier)   //los set no devuelven nada
                                       
    {
        checkParam(identifier >= 'A' && identifier <= 'Z', "Carácter debe estar entre A y Z");
        this.identifier = identifier; 
    }
    
    /**
     * Modifica el valor del atributo fuel
     * 
     * @param  fuel, nuevo combustible entre [0,5000] 
     * 
     */
    private void setFuel(int fuel)   //los set no devuelven nada
                                       
    {
        checkParam(fuel >= MIN_FUEL && fuel <= MAX_FUEL,"Caracter debe estar comprendido entre 0 y 5000" );
        this.fuel=fuel; 
    }
    
    /**
     * @return valor del atributo pilot
     */
    public Person getPilot(){
        return pilot;
    }
    
    /**
     * @return valor del atributo identifier
     */
    public char getIdentifier(){
        return identifier;
    }
    
    /**
     * @return valor del atributo fuel
     */
    public int getFuel(){
        return fuel;
    }
    
    /**
     * Permite volar el avión si tiene combustible 
     * decrementando en 1 el combustible
     * @return true si ha podido volar y false si no
     */
    public boolean fly() {
        if(getFuel() > MIN_FUEL) {
            setFuel(getFuel() -1);
            return true;
        } else {
            return false;
        }
    }
}
