
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class PlaneTest.
 *
 * @author  Miguel
 * @version 6-10-21
 */
public class PlaneTest
{
    /*
     * Pruebas del constructor por defecto
     * Piloto = null
     * Identificador 'A'
     * Combustible 0
     */
    @Test
    public void testPlaneWithoutParams(){
        Plane plane1 = new Plane(); //el new Plane llama al constructor. con el Plane plane1 creo un objeto llamado plane1 de la clase plane
        assertEquals(Plane.DEFAULT_IDENTIFIER, plane1.getIdentifier());
        assertEquals(Plane.DEFAULT_FUEL, plane1.getFuel());
        assertEquals(Plane.DEFAULT_PILOT, plane1.getPilot());
    }

    /*
     * Pruebas del constructor con parámetro piloto
     * 1- Piloto cualquiera
     * 2- null en lugar de un piloto
     */

    /**
     * 1-Piloto cualquiera
     */
    @Test
    public void testPlaneWithPilot(){
        Person pilot = new Person();     //llamada al constructor
        Plane plane1 = new Plane(pilot); //forma de llamar al constructor con un parámetro
        assertEquals(pilot, plane1.getPilot()); //un assertequals por cada atributo
        assertEquals(Plane.DEFAULT_IDENTIFIER, plane1.getIdentifier());
        assertEquals(Plane.DEFAULT_FUEL,plane1.getFuel());
    }

    /**
     * 2- recibo null
     */
    @Test
    public void testPlaneWithoutPilot(){
        //Person pilot = new Person(); //no necesito piloto al tener éste valor nulo    //llamada al constructor
        Plane plane1 = new Plane(null); //forma de llamar al constructor con un parámetro
        assertEquals(null, plane1.getPilot()); //un assertequals por cada atributo
        assertEquals(Plane.DEFAULT_IDENTIFIER, plane1.getIdentifier());
        assertEquals(Plane.DEFAULT_FUEL,plane1.getFuel());
    }
    
    /**
     * Prueba del constructor Plane con pilot1 como único parámetro
     */
    @Test
    public void testConstructorWithOnlyPilot(){
        Person pilot1=new Person();
        Plane plane=new Plane(pilot1);
        assertEquals(pilot1,plane.getPilot());
    }
    
    /**
     * Prueba del constructor Plane con Identifier como único parámetro
     */
    @Test
    public void testConstructorWithOnlyIdentifier(){
        Plane plane=new Plane('Z');
        assertEquals('Z',plane.getIdentifier());
    }
    
    /**
     * Prueba del constructor Plane con Fuel como único parámetro
     */
    @Test
    public void testConstructorWithOnlyFuel(){
        Plane plane=new Plane(50);
        assertEquals(50,plane.getFuel());
    }
}
