import java.util.ArrayList;
import java.util.Iterator;
/**
 * Representa un auditorio en el que se harán los conciertos
 * 
 * @author Miguel
 * @version 21-11-21
 */
public class Auditorium
{
    // instance variables
    private ArrayList<Concert> concerts; //colección de objetos de la clase Concert
    /**
     * Constructor sin parámetros de la clase Auditorium
     */
    public Auditorium()
    {
        concerts = new ArrayList<Concert>();
    }
    
    /**
     * El método getNumberOfConcerts retorna el tamaño de la lista concerts
     * 
     * @return el tamaño de la lista
     */
    public int getNumberOfConcerts()
    {
        return concerts.size();
    }
    
    /**
     * El método seekConcert busca un concierto en la colección por el nombre
     * Devuelve el concierto si existe o null en caso contrario
     * 
     * @param concertName, el nombre del concierto a buscar
     * @return el nombre del concierto en caso de existir o null en caso contrario
     */
    public String seekConcert(String concertName)
    {        
        checkParam(concertName != null, "Esperaba nombre de concierto pero fue null");
        for (Concert concert :concerts)
        {
            if (concert.getName().equals(concertName))
            {
                return concertName;
            }
        }
        return null;
    }
    
    /**
     * El método addConcert añade un concierto a la colección (la lista de 
     * conciertos del auditorio) siempre que no haya otro en la misma fecha
     * 
     * @param concertName, el nombre del concierto
     * @param price, el precio de la butaca del concierto 
     * @param date, la fecha del concierto
     */
    public void addConcert(String concertName, double price, Date date)
    {     
        Concert concert = seekConcertDate(date);
        if (concert == null)
        {
            concerts.add(new Concert(concertName,price,date));
        }
    }
    
    /**
     * El método removeConcerts borrará todos los conciertos de la colección
     * que se hayan celebrado en el año indicado en el parámetro.
     * 
     * @param year, el año en el que se celebraron los conciertos
     */
    public void removeConcerts(int year)
    {
        Iterator <Concert> it = concerts.iterator();
        while (it.hasNext())
        {
            Concert concert = it.next();
            if(concert.getDate().getYear() == year)
            {
                it.remove();
            }
        }
    }
    
    /**
     * El método getConcert retorna el concierto almacenado en una posición
     * de la lista
     * 
     * @param index, índice que representa la posición del elemento a retornar
     * @return el concierto almacenado en la posición de la lista 
     */
    public Concert getConcert(int index)
    {
        checkParam(index >= 0 && index < getNumberOfConcerts(),"Índice no válido");
        return concerts.get(index);
    }
    
    //metodos auxiliares
    
    /**
     * Combrueba una condición que si no se cumple, lanza excepción
     * 
     * @param condition, condición a evaluar
     * @param msg, mensaje de la excepción
     */
    private void checkParam(boolean condition, String msg)
    {
        if (!condition)
        {
            throw new IllegalArgumentException(msg);
        }
    }
    
    /**
     * Busca un concierto en la fecha indicada
     * 
     * @param date, fecha a buscar
     * @return concierto encontrado para esa fecha
     */
    private Concert seekConcertDate(Date date) 
    {
        for(Concert concert:concerts)
        {
            if(concert.getDate().equals(date)){
                return concert;
            }
        }
        return null;
    }
}
