
/**
 * Modelar una parte del auditorio de Oviedo para llevar la gestión 
 * de los conciertos que se van celebrando.
 * 
 * @author Miguel 
 * @version 20-11-21
 */
public class Concert
{
    // instance variables
    private String name; //el nombre del concierto
    private double price; //el precio de la butaca
    private Date date; //fecha en la que se celebra el concierto
    
    /**
     * Constructor con parámetros de la clase Concert
     * 
     * @param name, el nombre del concierto
     * @param price, el precio del concierto
     * @param date, la fecha del concierto
     */
    public Concert(String name,double price,Date date)
    {
        setName(name);
        setPrice(price);
        setDate(date);
    }
    
    /**
     * El método setName modificará el valor del atributo name por uno nuevo
     * 
     * @param el nuevo nombre del concierto
     */
    private void setName(String name)
    {
        checkParam(name != null, "No se ha recibido nombre del concierto");
        this.name = name;
    }
    
    /**
     * El método setPrice modificará el valor del atributo price por uno nuevo
     * 
     * @param el nuevo precio de la butaca
     */
    private void setPrice(double price)
    {
        checkParam(price > 0.0, "El precio de la butaca no puede ser negativo");
        this.price = price;
    }
    
    /**
     * El método setDate modificará los valores de la clase Date por unos nuevos
     * 
     * @param la nueva fecha del concierto
     */
    private void setDate(Date date)
    {
        checkParam(date != null, "Esperaba fecha pero fue null");
        this.date = date;
    }
    
    /**
     * El método getName retornará el valor almacenado en el atributo name
     * 
     * @return el valor almacenado en name
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * El método getPrice retornará el valor almacenado en el atributo price
     * 
     * @return el valor almacenado en price
     */
    public double getPrice()
    {
        return price;
    }
    
    /**
     * El método getDate retornará los valores almacenados en el atributo date
     * de la clase Date
     * 
     * @return los valores almacenados en date
     */
    public Date getDate()
    {
        return date;
    }
    
    //metodos auxiliares
    
    /**
     * Combrueba una condición que si no se cumple, lanza excepción
     * 
     * @param condition, condición a evaluar
     * @param msg, mensaje de la excepción
     */
    private void checkParam(boolean condition, String msg)
    {
        if (!condition)
        {
            throw new IllegalArgumentException(msg);
        }
    }
}
