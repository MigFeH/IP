
/**
 * La clase date representa una fecha
 * 
 * @author Miguel
 * @version 21-11-21
 */
public class Date
{
    // instance variables
    private int day; //día de la fecha
    private int month; //mes de la fecha
    private int year; //año de la fecha
    
    /**
     * Constructor de la clase Date con tres parámetros
     * 
     * @param day
     * @param month
     * @param year
     */
    public Date(int day,int month,int year)
    {
        setDay(day);
        setMonth(month);
        setYear(year);
    }
    
    /**
     * El método setDay modificará el valor del atributo day por uno nuevo
     * 
     * @param el nuevo día de la fecha
     */
    private void setDay(int day)
    {
        checkParam(day > 0, "El número del día no puede ser negativo");
        this.day = day;
    }
    
    /**
     * El método setMonth modificará el valor del atributo month por uno nuevo
     * 
     * @param el nuevo mes de la fecha
     */
    private void setMonth(int month)
    {
        checkParam(month > 0, "El número del mes no puede ser negativo");
        this.month = month;
    }
    
    /**
     * El método setYear modificará el valor del atributo year por uno nuevo
     * 
     * @param el nuevo año de la fecha
     */
    private void setYear(int year)
    {
        checkParam(year > 0, "El número del año no puede ser negativo");
        this.year = year;
    }
    
    /**
     * El método getDay retornará el valor almacenado en el atributo day
     * 
     * @return el valor almacenado en day
     */
    public int getDay()
    {
        return day;
    }
    
    /**
     * El método getMOnth retornará el valor almacenado en el atributo month
     * 
     * @return el valor almacenado en month
     */
    public int getMonth()
    {
        return month;
    }
    
    /**
     * El método getYear retornará el valor almacenado en el atributo year
     * 
     * @return el valor almacenado en year
     */
    public int getYear()
    {
        return year;
    }
    
    //métodos auxiliares
    
    /**
     * Combrueba una condición que si no se cumple, lanza excepción
     * 
     * @param condition, condición a evaluar
     * @param msg, mensaje de la excepción
     */
    private void checkParam(boolean condition, String msg)
    {
        if (!condition)
        {
            throw new IllegalArgumentException(msg);
        }
    }
}
