
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class AuditoriumTest.
 *
 * @author Miguel
 * @version 21-11-21
 */
public class AuditoriumTest
{
     /*
      * Pruebas del método seekConcert con distintas condiciones
      * 1-Que haya concierto
      * 2-Que no haya concierto
      */
     /**
      * Prueba 1 de seekConcert
      * 1-Que haya concierto
      */
     @Test
     public void testSeekConcertWithConcert()
     {
        //creación de auditorio
        Auditorium au = new Auditorium();
        
        //creación de fecha
        Date date1 = new Date(05,06,2037);
        
        //creación de los conciertos 
        Concert c1 = new Concert("TomorrowLand",499.99,date1);
        Concert c2 = new Concert("ElectroParty",238.99,date1);
        Concert c3 = new Concert("Riverland",147.99,date1);
        
        //añadir los conciertos a la lista
        au.addConcert("TomorrowLand",499.99,date1);
        au.addConcert("ElectroParty",238.99,date1);
        au.addConcert("Riverland",147.99,date1);
        
        //comprobación de los resultados
        assertEquals(au.getConcert(0), au.seekConcert("TomorrowLand"));
        assertEquals(au.getConcert(1), au.seekConcert("ElectroParty"));
        assertEquals(au.getConcert(2), au.seekConcert("Riverland"));
    }
    
    /**
     * Prueba 2 de seekConcert
     * 2-Que no haya concierto
     */
    @Test
    public void testSeekConcertWithoutConcert() 
    {
        Auditorium au = new Auditorium();
        
        Date date1 = new Date(05,06,2037);
        
        Concert c1 = new Concert("TomorrowLand",499.99,date1);
        Concert c2 = new Concert("ElectroParty",238.99,date1);
        Concert c3 = new Concert("Riverland",147.99,date1);
        
        au.addConcert("TomorrowLand",499.99,date1);
        au.addConcert("ElectroParty",238.99,date1);
        au.addConcert("Riverland",147.99,date1);
        
        assertEquals(null, au.seekConcert("Tequila"));
    }
    
    /**
     * Prueba de addConcert (se añade un concierto)
     */
    @Test
    public void testAddConcert() 
    {
        Auditorium au = new Auditorium();
        
        Date date1 = new Date(05,06,2037);
        Date date2 = new Date(05,06,2038);
        Date date3 = new Date(05,06,2039);
        
        Concert c1 = new Concert("TomorrowLand",499.99,date1);
        Concert c2 = new Concert("ElectroParty",238.99,date2);
        Concert c3 = new Concert("Riverland",147.99,date3);
        
        au.addConcert("TomorrowLand",499.99,date1);
        au.addConcert("ElectroParty",238.99,date2);
        au.addConcert("Riverland",147.99,date3);
        
        assertEquals(3,au.getNumberOfConcerts());
    }

    /**
     * Prueba de removeConcert (se borra un concierto)
     */
    @Test
    public void testRemoveConcert() {
        try {
            Auditorium au = new Auditorium();
        
            Date date1 = new Date(05,06,2037);
        
            Concert c1 = new Concert("TomorrowLand",499.99,date1);
            Concert c2 = new Concert("ElectroParty",238.99,date1);
            Concert c3 = new Concert("Riverland",147.99,date1);
        
            au.addConcert("TomorrowLand",499.99,date1);
            au.addConcert("ElectroParty",238.99,date1);
            au.addConcert("Riverland",147.99,date1);
        
            au.removeConcerts(2037);
            au.getConcert(1);
            
            fail("Esperaba salto de excepción");    
        }catch(IllegalArgumentException e) {
            assertEquals("Índice no válido", e.getMessage());
        }
    }
}
