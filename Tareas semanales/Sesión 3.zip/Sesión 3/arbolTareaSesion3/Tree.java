
/**
 * Write a description of class Tree here.
 * 
 * @author (Miguel) 
 * @version (22/09/2021)
 */
public class Tree
{
    public static final int MAX_NUMBER_OF_FLOWERS = 12;

    public static final String DEFAULT_TYPE_OF_TREE = "Manzano";
    public static final int DEFAULT_NUMBER_OF_FLOWERS = 11;
    public static final int DEFAULT_NUMBER_OF_FRUITS = 5;

    // instance variables
    private String typeOfTree;      //tipo de árbol, como un manzano o un peral
    private int maxNumberOfFlowers; //máximo número de flores del árbol
    private int numberOfFlowers;    //número de flores del árbol
    private int numberOfFruits;     //número de frutas del árbol

    /**
     * Constructor for objects of class Tree
     */
    public Tree()
    {
        String typeOffTree = DEFAULT_TYPE_OF_TREE;
        int maxNumberOfFlowers = MAX_NUMBER_OF_FLOWERS;
        int numberOfFlowers = DEFAULT_NUMBER_OF_FLOWERS;
        int numberOfFruits = DEFAULT_NUMBER_OF_FRUITS;
    }

    /**
     * Modifica el valor del atributo typeOfTree
     * 
     * @param  newTypeOfTree nuevo valor para typeOfTree
     * 
     */
    public void setTypeOfTree(String newTypeOfTree)
    {
        typeOfTree = newTypeOfTree;
    }

    /**
     * Modifica el valor del atributo numberOfFlowers
     * 
     * @param  newNumberOfFlowers nuevo valor para numberOfFlowers
     * 
     */
    public void setNumberOfFlowers(int newNumberOfFlowers)
    {
        checkParam(newNumberOfFlowers <= MAX_NUMBER_OF_FLOWERS);
        checkParam2(newNumberOfFlowers >= 0);
        numberOfFlowers = newNumberOfFlowers;
    }

    // /**
    // * Modifica el valor del atributo maxNumberOfFlowers
    // * 
    // * @param  newMaxNumberOfFlowers nuevo valor para MaxNumberOfFlowers
    // * 
    // */
    // public void setMaxNumberOfFlowers(int newMaxNumberOfFlowers)
    // {
    // checkParam4(newMaxNumberOfFlowers >= numberOfFlowers);
    // checkParam5(newMaxNumberOfFlowers >=0);
    // maxNumberOfFlowers = newMaxNumberOfFlowers;
    // }

    /**
     * Modifica el valor del atributo numberOfFruits
     * 
     * @param  newNumberOfFruits nuevo valor para numberOfFruits
     * 
     */
    public void setNumberOfFruits(int newNumberOfFruits)
    {
        checkParam3(newNumberOfFruits >=0);
        numberOfFruits = newNumberOfFruits;
    }

    /**
     * Comprueba si la condición es correcta. Si no lo es, lanza excepción
     *
     * @param condition condición a comprobar
     *
     */
    private void checkParam(boolean condition)
    {
        if (! condition) {
            throw new IllegalArgumentException("El número de flores no puede exceder el número máximo de estas");
        }
    }

    /**
     * Comprueba si la condición es correcta. Si no lo es, lanza excepción
     *
     * @param condition condición a comprobar
     *
     */
    private void checkParam4(boolean condition)
    {
        if (! condition) {
            throw new IllegalArgumentException("El número máximo de flores no puede ser inferior al número de flores que ya tiene el árbol");
        }
    }

    /**
     * Comprueba si la condición es correcta. Si no lo es, lanza excepción
     *
     * @param condition condición a comprobar
     *
     */
    private void checkParam5(boolean condition)
    {
        if (! condition) {
            throw new IllegalArgumentException("El número máximo de flores no puede ser negativo");
        }
    }

    /**
     * Comprueba si la condición es correcta. Si no lo es, lanza excepción
     *
     * @param condition2 condición a comprobar
     *
     */
    private void checkParam2(boolean condition)
    {
        if (! condition) {
            throw new IllegalArgumentException("El número de flores no puede negativo");
        }
    }

    /**
     * Comprueba si la condición es correcta. Si no lo es, lanza excepción
     *
     * @param condition condición a comprobar
     *
     */
    private void checkParam3(boolean condition)
    {
        if (! condition) {
            throw new IllegalArgumentException("El número de frutas no puede ser negativo");
        }
    }
    
    /**
     * Comprueba si la condición es correcta. Si no lo es, lanza excepción
     *
     * @param condition condición a comprobar
     *
     */
    private void checkParam6(boolean condition)
    {
        if (! condition) {
            throw new IllegalArgumentException("Ya no queda más fruta por recoger");
        }
    }

    /**
     * Devuelve el valor del atributo typeOfTree
     *
     *
     * @return     el valor del atributo typeOfTree, de tipo String
     */
    public String getTypeOfTree()
    {
        return typeOfTree;
    }

    /**
     * Devuelve el valor del atributo numberOfFlowers
     *
     *
     * @return     el valor del atributo numberOfFlowers, de tipo int
     */
    public int getNumberOfFlowers()
    {
        return numberOfFlowers;
    }

    /**
     * Devuelve el valor del atributo maxNumberOfFlowers
     *
     *
     * @return     el valor del atributo maxNumberOfFlowers, de tipo int
     */
    public int getMaxNumberOfFlowers()
    {
        return MAX_NUMBER_OF_FLOWERS;
    }

    /**
     * Devuelve el valor del atributo numberOfFruits
     *
     *
     * @return     el valor del atributo numberOfFruits, de tipo int
     */
    public int getNumberOfFruits()
    {
        return numberOfFruits;
    }

    /**
     * Devuelve los datos del árbol con el siguiente formato:
     * tipo de árbol-ńumero máximo de flores-número de flores-número de frutas
     * EJEMPLO
     * Manzano-25-7-3
     *
     * 
     * @return     cadena de datos del árbol en el formato anterior
     */
    public String toString()
    {
        String result = getTypeOfTree() + "-" + MAX_NUMBER_OF_FLOWERS + "-" + getNumberOfFlowers () + "-" + getNumberOfFruits();
        return result;
    }

    /**
     * Imprime por pantalla los valores de las propiedades del objeto árbol 
     * con el siguiente formato:
     * "Valores de las propiedades del árbol: Manzano-25-7-3"
     * Siendo respectivamente el tipo de árbol, número máximo de flores, número de flores
     * y número de frutas
     *
     *
     */
    public void print ()
    {
        System.out.println("Valores de las propiedades del árbol: " + getTypeOfTree() + "-" + MAX_NUMBER_OF_FLOWERS + "-" + getNumberOfFlowers() + "-" + getNumberOfFruits() );
    }

    /**
     * Método water: Si el número de flores es menor que el número máximo 
     * de flores entonces se incrementa en una unidad el número de flores 
     *
     */
    public void water()
    {
        if (this.numberOfFlowers<MAX_NUMBER_OF_FLOWERS){
            this.setNumberOfFlowers(this.getNumberOfFlowers()+1);
        } else {
            if (this.numberOfFruits<MAX_NUMBER_OF_FLOWERS){
                this.setNumberOfFruits(this.getNumberOfFruits()+1);
                this.setNumberOfFlowers(this.getNumberOfFlowers()-1);
            }
        }
    }

    /**
     * Método gatherFruit recogerá la fruta y hará que disminuya el número de
     * frutas en una unidad y devuelva las frutas que quedan
     *
     * @return el número de frutas que quedan
     */
    public int gatherFruit()
    {
        checkParam3 (numberOfFruits >= 0);
        setNumberOfFruits(getNumberOfFruits()-1);
        return numberOfFruits;
    }

    /**
     * El método harvest recogerá la cosecha al completo y devolverá el número 
     * de frutas recogidas.
     * También le dará valor 0 a la propiedad numberOfFruits
     *
     * @return el número de frutas recogidas
     */
    public int harvest()
    {
        checkParam6 (numberOfFruits >= 0); //si el número de frutas es mayor que 0, entonces se ejecutará el método
        int harvest = numberOfFruits;
        setNumberOfFruits(0);
        return harvest;
    }
}
