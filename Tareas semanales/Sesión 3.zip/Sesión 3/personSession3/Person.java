/**
 * Clase Person define una persona con nombre y edad.
 * Se define los métodos set y get para cada atributo
 *Para la sesión 1
 * 
 * @author (Miguel) 
 * @version 15-9-2021
 */
public class Person
{
    //def. de atributos constantes
    public static final int MIN_AGE = 0;            //edad de nacimiento de una persona en años
    public static final int MAX_AGE = 120;
    
    public static final int ADULTHOOD_AGE = 18;     //edad adulta de una persona
    public static final int RETIREMENT_AGE = 65;    //edad de jubilación de una persona
    
    public static final boolean GENDER_FEMALE = false;
    public static final boolean GENDER_MALE = true;
    
    public static final String DEFAULT_NAME = "Fernando"; //valor de nombre por defecto
    
    public static final String DEFAULT_SURNAME = "Alonso";
    public static final int DEFAULT_AGE = 40;
    public static final boolean DEFAULT_GENDER = GENDER_MALE;
    
    
    //variable de una instancia
    private String name;        //nombre de la persona
    private int age;            //edad de la persona
    private String surname;     //apellido de la persona
    private boolean gender;     //género de la persona
    private int criticalAge;    

    /**
     * Constructor con valores por defecto
     */
    public Person()
    {
        //name = "Fernando";
        setName(DEFAULT_NAME);
        age = 35;
        setSurname ("Alonso");
        setGender (GENDER_MALE);   //Se asignara true como masculino, y false como femenino
    }

    /**
     * Constructor con parámetro la edad, el resto de datos los valores por defecto
     * @param age, edad de la persona
     */
    public Person(int age)
    {
        //name = "Fernando";
        setName("Fernando");
        setAge(age);
        setSurname ("Alonso");
        setGender (true); //Se asignara true como masculino, y false como femenino
        
        
    }

    /**
     * Modifica el valor del atributo name
     * 
     * @param  newName   nuevo valor para name
     *
     */
    public void setName(String newName)
    {
        name = newName; 
    }

    /**
     * Devuelve el valor del atributo name
     *
     * 
     * @return     el valor del atributo name, de tipo String
     */
    public String getName()
    {
        return name;
    }

    /**
     * Modifica el valor del atributo age
     * 
     * @param  newAge   nuevo valor para age
     *
     */
    public void setAge(int age)
    {
        checkParam(age >= MIN_AGE, "La edad no puede ser nagetiva" );
        checkParam(age < MAX_AGE, "La edad debe ser menos que 120"); 
        this.age = age;     //this se refiere al atributo (cuando el nombre del parámetro es igual al del atributo)
    }

    /**
     * Comprueba si la condición es correcta. Si no lo es, lanza excepción
     *
     * @param condition condición a comprobar
     * 
     */
    private void checkParam(boolean condition)
    {
        if (! condition ) {
            throw new IllegalArgumentException("Parámetro incorrecto");
        }
    }
    
    /**
     * Comprueba si la condición es correcta. Si no lo es, lanza excepción
     * con el mensaje recibido como parámetro
     * @param condition condición a comprobar
     * @param msg, mensaje para la excepción
     * 
     */
    private void checkParam(boolean condition, String msg)
    {
        if (! condition ) {
            throw new IllegalArgumentException(msg);
        }
    }

    /**
     * Devuelve el valor del atributo age
     *
     * 
     * @return     el valor del atributo age, de tipo int
     */
    public int getAge()
    {
        return age;
    }

    /**
     * Modifica el valor del atributo surname
     * 
     * @param  newSurname nuevo valor para surname, de tipo String
     *
     */
    public void setSurname(String newSurname)
    {
        surname = newSurname;
    }

    /**
     * Devuelve el valor del atributo surname 
     *
     * 
     * @return     el valor del atributo surname, de tipo String
     */
    public String getSurname()
    {
        return surname;
    }

    /**
     * Modifica el valor del atributo gender
     * 
     * @param  newGender nuevo valor para gender, de tipo boolean
     *
     */
    public void setGender (boolean newGender)
    {
        gender = false;
        gender = true;
    }

    /**
     * Devuelve el valor del atributo gender 
     *
     * 
     * @return     el valor del atributo gender, de tipo boolean
     */
    public boolean getGender()
    {
        return gender;
    }

    /**
     * Imprime por pantalla nombre y edad de la persona con el siguiente
     * formato
     * "Me llamo Fernando y tengo 40 años"
     * Además imprime una línea con todos los datos de la persona
     * Datos de la persona: FERNANDO-Alonso-40-MASCULINO (mismo formato de toString)
     *
     */
    public void print()
    {
        System.out.println("Me llamo " + getName() + " y tengo " + getAge() + " años");
        System.out.println("Y el año que viene tendré " + (age + 1) + " años");
        System.out.println("Datos de la persona: " + this.toString() ); //es quivalente con y sin el this
    }

    /**
     * Devuelve los datos de la persona con el siguiente formato:
     * nombre(en mayúsculas)-apellido-edad-MASCULINO (o FEMENINO)
     * EJEMPLO
     * FERNANDO-Alonso-40-MASCULINO
     * 
     * 
     * @return     cadena con los datos de la persona en el formato anterior
     */
    public String toString()
    {
        String result = name.toUpperCase() + "-" + this.getSurname() + "-" + this.getAge() + "-" + "-" + genderToString();
        return result;
    }

    /**
     * El método getCriticalAge comprobará la edad de la persona 
     * e indicará si es menor de edad, los años que le quedan 
     * para alcanzar los 18 años; si esa persona tiene entre 18 y 64 años,
     * indicará los años que le quedan para jubilarse (sobre los 65 años);
     * y si esa persona ya se ha jubilado, indicará hace cuanto que se ha jubilado.
     * 
     * @return  los años que correspondería a cada situación de las condiciones antes mencionadas
     */
    public int getCriticalAge()
    {
        if (age < ADULTHOOD_AGE) { 
            criticalAge = (ADULTHOOD_AGE - age); //si es menor de edad, que reste la mayoría de edad menos la edad de la persona 
        }
        if (ADULTHOOD_AGE<= age) {
            criticalAge = (age - RETIREMENT_AGE); //si es mayor de edad y no está jubilado (65 años), que reste la edad de jubilación menos la edad de la persona
        }
        if (age >= RETIREMENT_AGE) {
            criticalAge = (age - RETIREMENT_AGE); //si ya está jubilado, que le reste a la edad que la persona tiene, la edad de jubilación (65 años)
        }
        return criticalAge;
    }
    
    /**
     * Devuelve "MASCULINO" o "FEMENINO" según sea el género de la persona
     * @return cadena con mensaje "MASCULINO" o "FEMENINO"
     */
    private String genderToString() {
        if (gender== GENDER_FEMALE) {
            return "FEMENINO";
        } else {
            return "MASCULINO";
        }
    }
}
