

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class PersonTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class PersonTest
{
    /*
     * Pruebas para setAge
     * Casos de uso:
     * 1- Llamo a setAge con valor dentro de los límites
     * 2- Llamo a setAge con valor debajo del límite inferior
     * 3- Llamo a setAge con valor superior al límite superior
     * 4- Llamo a setAge con valor en límite inferior
     * 5- Llamo a setAge con valor en límite superior
     * 
     */
    /*
     * Pruebas de setAge
     * 1- Llamo a setAge con valor dentro de los límites
     */
    @Test
    public void testSetAgeInsideLimits() {
        Person person1 = new Person ();
        person1.setAge(25);
        assertEquals(25,person1.getAge());
    }
    
    /*
     * Pruebas de setAge
     * 2- Llamo a setAge con valor debajo del límite inferior
     */
    @Test
    public void testSetAgeBelowLimits() {
        Person person1 = new Person ();
        try {
            person1.setAge(Person.MIN_AGE -1);
            fail("Esperaba salto de excepción");
        } catch (IllegalArgumentException e) {
            assertEquals ("La edad no puede ser negativa", e.getMessage());
        }
    }
    
        /*
     * Pruebas de setAge
     * 3- Llamo a setAge con valor superior al límite superior
     */
    @Test
    public void testSetAgeUpperLimits() {
        Person person1 = new Person ();
        try {
            person1.setAge(Person.MAX_AGE +1);
            fail("Esperaba salto de excepción");
        } catch (IllegalArgumentException e) {
            assertEquals ("La edad debe ser menor que 120", e.getMessage());
        }
    }
    }

