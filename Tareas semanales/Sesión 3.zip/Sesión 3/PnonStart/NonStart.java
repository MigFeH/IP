
/**
 * Write a description of class nonStart here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NonStart
{

    /**
     * Constructor for objects of class nonStart
     */
    public NonStart()
    {

    }
    
    /**
     * El método nonStart que concadena los String a y b quitando la primera letra de ambos String
     *
     * @param los String a y b
     * @return el String a+b
     */
    public String nonStart(String a, String b) {
      a = a.substring(1);
      b = b.substring(1);
      return a+b;
    } 
}
