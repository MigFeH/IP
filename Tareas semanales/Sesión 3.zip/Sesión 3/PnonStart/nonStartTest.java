

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class nonStartTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class nonStartTest
{
    /**
     * Default constructor for test class nonStartTest
     */
    public nonStartTest()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @Test
    public void prueba1()
    {
        NonStart p1 = new NonStart();
        assertEquals("ellohere", p1.nonStart("hello","there"));
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @Test
    public void prueba2()
    {
        NonStart p2 = new NonStart();
        assertEquals("avaode", p2.nonStart("java","code"));
    }
}
