
/**
 * Gestiona los asientos del avión
 * 
 * @author Miguel
 * @version 24-11-21
 */
public class SeatManager
{
    //constantes//
    public static final int MIN_FIRST_ROWS = 3;
    public static final int MIN_STANDARD_ROWS = 3;

    public static final int MAX_FIRST_ROWS = 10;
    public static final int MAX_STANDARD_ROWS = 40;

    public static final int COLUMNS = 6;

    //variables de instancia//
    private int firstRows; //número de filas en primera
    private int standardRows; //número de filas en clase turista
    private Person[][] seats; //array bidimensional para la matriz de asientos, contiene los pasajeros

    /**
     * Constructor con parámetros de la clase SeatManager
     */
    public SeatManager(int first, int standard)
    {
        setFirstRows(first);
        setStandardRows(standard);
        setSeats(new Person[firstRows + standardRows][COLUMNS]);
    }

    //métodos//

    /**
     * Modifica el valor del atributo firstRows
     * 
     * @param first, número de filas en primera
     */
    private void setFirstRows(int first)
    {
        checkParam(first >= MIN_FIRST_ROWS && first <= MAX_FIRST_ROWS, "Número de filas en clase primera incorrecto");
        this.firstRows = first;
    }

    /**
     * Modifica el valor del atributo standardRows
     * 
     * @param standard, número de filas en clase turista
     */
    private void setStandardRows(int standard)
    {
        checkParam(standard >= MIN_STANDARD_ROWS && standard <= MAX_STANDARD_ROWS, "Número de filas en clase turista incorrecto");
        this.standardRows = standard;
    }

    /**
     * Modifica el valor del atributo seats (crea una matriz con x filas y columnas)
     * 
     * @param seats, nueva matriz de asientos 
     */
    private void setSeats(Person[][] seats)
    {
        checkParam(seats != null, "Null en lugar de matriz de pasajeros");

        checkParam(seats.length >= MIN_FIRST_ROWS + MIN_STANDARD_ROWS 
            && seats.length <= MAX_FIRST_ROWS + MAX_STANDARD_ROWS, "Número de filas de la matriz incorrecta");

        checkParam(seats[0].length == COLUMNS, "Número de asientos por fila incorrectos");

        this.seats = seats;
    }

    /**
     * Retorna el valor almacenado en el atributo firstRows
     * 
     * @return el valor almacenado en el atributo
     */
    public int getFirstRows()
    {
        return firstRows;
    }

    /**
     * Retorna el valor almacenado en el atributo standardRows
     * 
     * @return el valor almacenado en el atributo
     */
    public int getStandardRows()
    {
        return standardRows;
    }

    /**
     * Retorna la persona sentada (en la matriz bidimensional seats)
     * mediante una posicion en las filas y en las columnas como parámetros
     * 
     * @param row, número de fila del asiento de la persona a buscar
     * @param column, número de columna del asiento de la persona a buscar
     * @return la persona que ocupa el asiento seleccionado
     */
    public Person getSeats(int row,int column)
    {
        checkParam(row >= 0 && row < seats.length, "Número de filas de la matriz incorrecta");
        checkParam(column >= 0 && column < seats[0].length, "Número de asientos por fila incorrectos");

        return seats[row][column];
    }

    /**
     * Retorna la matriz bidimensional de asientos
     * 
     * @return la matriz bidimensional
     */
    public Person[][] getSeats()
    {
        return seats;
    }

    /**
     * El método bookSeat asigna a una persona al asiento cuya fila y columna recibe como parámetro 
     * 
     * @param passenger, pasajero que hace la reserva
     * @param row, número de fila de la reserva
     * @param column, número de columna de la reserva
     */
    public boolean bookSeat(Person passenger, int row, int column)
    {
        checkParam(passenger != null, "Esperaba pasajero pero fue null");

        checkParam(row >= 0, "Número de fila fuera de límite");
        checkParam(row < seats.length, "Número de fila fuera de límite");

        checkParam(column >= 0, "Número de columna fuera de límite");
        checkParam(column < COLUMNS, "Número de columna fuera de límite");

        if (seats[row][column] == null){
            seats[row][column] = passenger;
            return true;
        } else {
            return false;
        }
    }

    /**
     * Libera un asiento del avión retornando la persona que lo ocupaba
     * 
     * @param row, fila donde se encuentra la posición a liberar
     * @param column, columna donde se encuentra la posición a liberar
     * 
     * @return person, persona liberada o null si no hay nadie
     */
    public Person releaseSeat(int row, int column)
    {
        checkParam(row >= 0 && row < seats.length, "Fila fuera de límites");
        checkParam(column >= 0 && column < COLUMNS, "Columna fuera de límites");

        Person result = seats[row][column];
        seats[row][column] = null;
        return result;
    }

    /**
     * El método oldestPassenger devolverá al pasajero de más edad sentado en 
     * el avión o null si el avión está vacío
     * 
     * @return el pasajero de más edad en el avión, o null si el avión está vacío
     */
    public Person oldestPassenger()
    {        
        Person oldestPassenger = null;
        int age = 0;
        for(int i = 0; i < seats.length; i++)
        {
            for(int j = 0; j < seats[0].length; j++)
            {
                if(seats[i][j] != null && seats[i][j].getAge() > age)
                {
                    oldestPassenger = seats[i][j];
                    age = oldestPassenger.getAge();
                }
            }
        }
        return oldestPassenger;
    }
    
    /**
     * El método numberOfFreeSeats devolverá el número de asientos libres 
     * en la fila del avión que se le pasa como parámetro
     * 
     * @param row, fila del avión a comprobar el número de asientos libres
     * @return el número de asientos libres en la fila indicada en el parámetro
     */
    public int numberOfFreeSeats(int row)
    {
        int cont = 0;
        for(int j = 0; j < seats[row].length; j++)
        {
            if(seats[row][j] == null)
            {
                cont = cont + 1;
            }
        }
        return cont;
    }
    
    /**
     * El método print mostrará el estado de los asientos del avión
     * Una X para un adulto
     * Una C para un niño
     * Un ? para un asiento libre con el siguiente formato:
     * 
     *     0   1   2   3   4   5
     *     
     * 0   X   X   ?   ?   ?   X
     * 1   X   X   X   ?   ?   ?
     * 2   ?   X   ?   ?   ?   ?
     * 3   X   X   ?   X   X   X
     * 4   X   X   X   X   X   X
     * 5   X   X   ?   X   X   X
     * 6   X   X   X   X   X   X
     * 7   X   X   ?   ?   ?   X
     * ...
     */
    public void print()
    {
        System.out.print("  ");
        
        for (int j =  0; j < seats[0].length; j++) 
        {
            System.out.print(j + " ");
        }
        
        System.out.println(" ");
        for (int  i = 0; i < seats.length; i++) 
        {
            System.out.print(i + " ");
            for (int j = 0; j < seats[i].length;j++) 
            {
                if (seats[i][j] == null){
                    System.out.print('?' + " ");
                }else if (seats[i][j].getAge() >= Person.ADULTHOOD_AGE){
                    System.out.print('X' + " ");
                }else {
                    System.out.print('C' + " ");
                }
            }
            System.out.println(" ");
        }        
    }
    
    //métodos auxiliares//

    /**
     * El método checkParam comprueba una condición, y si es falsa, lanza una excepción
     * con un mensaje
     * 
     * @param condition, la condición a evaluar
     * @param msg, el mensaje de la excepción
     */
    private void checkParam(boolean condition, String msg)
    {
        if (!condition)
        {
            throw new IllegalArgumentException(msg);
        }
    }
}