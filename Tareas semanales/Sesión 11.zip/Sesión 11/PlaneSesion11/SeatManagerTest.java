

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class SeatManagerTest.
 *
 * @author Miguel
 * @version 24-11-21
 */
public class SeatManagerTest
{
    /*
     * Pruebas del constructor con dos parámetros
     * número de asientos es primera y en clase turista
     * Crea una matriz de asientos con 6 columnas y la suma de los de primera
     * y turista como filas
     * 
     * Casos de uso:
     * 1-Ambos parámetros dentro de los límites
     * 2-Ambos parámetros estén en límite inferior
     * 3-Ambos parámetros estén en límite superior
     * 4-First fuera de límite por debajo y standard correcto
     * 5-Standard fuera del límite por debajo y first correcto
     * 6-First fuera de límite por encima y standard correcto
     * 7-Standard fuera del límite por encima y first correcto
     */
    /**
     * Prueba 1 del constructor con dos parámetros
     * Ambos parámetros dentro de los límites
     */
    @Test
    public void testSeatManagerBothOk()
    {
        //creación de los parámetros
        int firstRows = (SeatManager.MIN_FIRST_ROWS + SeatManager.MAX_FIRST_ROWS) / 2;
        int standardRows = (SeatManager.MIN_STANDARD_ROWS + SeatManager.MAX_STANDARD_ROWS) / 2;
        
        //creación de un objeto de la clase SeatManager
        SeatManager sm = new SeatManager(firstRows, standardRows);
        
        //comprobación de que el objeto existe
        assertNotNull(sm);
        
        //comprobación de resultados
        assertEquals(firstRows, sm.getFirstRows());
        assertEquals(standardRows, sm.getStandardRows());
        
        //comprobación de que la matiz existe
        assertNotNull(sm.getSeats());
        
        //comprobación de que la matriz tiene el número de filas correctas
        assertEquals(firstRows + standardRows, sm.getSeats().length);
        
        //comprobación de que la matriz tiene el número de columnas correctas
        assertEquals(SeatManager.COLUMNS, sm.getSeats()[0].length);
    }
    
    /**
     * Prueba 2 del constructor con dos parámetros
     * Ambos parámetros estén en límite inferior
     */
    @Test
    public void testSeatManagerBothOnLowerLimits()
    {
        int firstRows = SeatManager.MIN_FIRST_ROWS;
        int standardRows = SeatManager.MIN_STANDARD_ROWS;
        
        //creación de un objeto de la clase SeatManager
        SeatManager sm = new SeatManager(firstRows,standardRows);
        
        //comprobación de que el objeto existe
        assertNotNull(sm);
        
        //comprobación de resultados
        assertEquals(3, sm.getFirstRows());
        assertEquals(3, sm.getStandardRows());
        
        //comprobación de que la matiz existe
        assertNotNull(sm.getSeats());
        
        //comprobación de que la matriz tiene el número de filas correctas (firstRows + standardRows)
        assertEquals((sm.getFirstRows()) + (sm.getStandardRows()), sm.getSeats().length);
        
        //comprobación de que la matriz tiene el número de columnas correctas (SeatManager.COLUMNS)
        assertEquals(SeatManager.COLUMNS, sm.getSeats()[0].length);
    }
    
    /**
     * Prueba 3 del constructor con dos parámetros
     * Ambos parámetros estén en límite superior
     */
    @Test
    public void testSeatManagerBothOnHigherLimits()
    {
        int firstRows = SeatManager.MAX_FIRST_ROWS;
        int standardRows = SeatManager.MAX_STANDARD_ROWS;
        
        //creación de un objeto de la clase SeatManager
        SeatManager sm = new SeatManager(firstRows,standardRows);
        
        //comprobación de que el objeto existe
        assertNotNull(sm);
        
        //comprobación de resultados
        assertEquals(SeatManager.MAX_FIRST_ROWS, sm.getFirstRows());
        assertEquals(SeatManager.MAX_STANDARD_ROWS, sm.getStandardRows());
        
        //comprobación de que la matiz existe
        assertNotNull(sm.getSeats());
        
        //comprobación de que la matriz tiene el número de filas correctas (firstRows + standardRows)
        assertEquals((sm.getFirstRows()) + (sm.getStandardRows()), sm.getSeats().length);
        
        //comprobación de que la matriz tiene el número de columnas correctas (SeatManager.COLUMNS)
        assertEquals(SeatManager.COLUMNS, sm.getSeats()[0].length);
    }
    
    /**
     * Prueba 4 del constructor con dos parámetros
     * First fuera de límite por debajo y standard correcto
     */
    @Test
    public void testSeatManagerWithWrongLowerFirst()
    {
        try{
            int firstRows = SeatManager.MIN_FIRST_ROWS - 1;
            int standardRows = SeatManager.MAX_STANDARD_ROWS;
        
            //creación de un objeto de la clase SeatManager
            SeatManager sm = new SeatManager(firstRows,standardRows);
            
            fail("Esperaba un salto de excepción");    
        } catch (IllegalArgumentException e) {
            assertEquals("Número de filas en clase primera incorrecto", e.getMessage());
        }
    }
    
    /**
     * Prueba 5 del constructor con dos parámetros
     * Standard fuera del límite por debajo y first correcto
     */
    @Test
    public void testSeatManagerWithWrongLowerStandard()
    {
        try{
            int firstRows = SeatManager.MAX_FIRST_ROWS;
            int standardRows = SeatManager.MIN_STANDARD_ROWS - 1;
        
            //creación de un objeto de la clase SeatManager
            SeatManager sm = new SeatManager(firstRows,standardRows);
            
            fail("Esperaba un salto de excepción");    
        } catch (IllegalArgumentException e) {
            assertEquals("Número de filas en clase turista incorrecto", e.getMessage());
        }
    }
    
    /**
     * Prueba 6 del constructor con dos parámetros
     * First fuera de límite por encima y standard correcto
     */
    @Test
    public void testSeatManagerWithWrongHigherFirst()
    {
        try{
            int firstRows = SeatManager.MAX_FIRST_ROWS + 1;
            int standardRows = SeatManager.MAX_STANDARD_ROWS;
        
            //creación de un objeto de la clase SeatManager
            SeatManager sm = new SeatManager(firstRows,standardRows);
            
            fail("Esperaba un salto de excepción");    
        } catch (IllegalArgumentException e) {
            assertEquals("Número de filas en clase primera incorrecto", e.getMessage());
        }
    }
    
    /**
     * Prueba 7 del constructor con dos parámetros
     * Standard fuera del límite por encima y first correcto
     */
    @Test
    public void testSeatManagerWithWrongHigherStandard()
    {
        try{
            int firstRows = SeatManager.MAX_FIRST_ROWS;
            int standardRows = SeatManager.MAX_STANDARD_ROWS + 1;
        
            //creación de un objeto de la clase SeatManager
            SeatManager sm = new SeatManager(firstRows,standardRows);
            
            fail("Esperaba un salto de excepción");    
        } catch (IllegalArgumentException e) {
            assertEquals("Número de filas en clase turista incorrecto", e.getMessage());
        }
    }
    
    /*
     * Pruebas del método bookSeat con distintas condiciones:
     * 1-Que el pasajero sea null (excepción)
     * 2-Que el número de la fila en la que se le asigna el asiento al pasajero sea negativo (excepción)
     * 3-Que el número de la fila en la que se le asigna el asiento al pasajero esté fuera de rango (excepción)
     * 4-Que el número de la columna en la que se le asigna el asiento al pasajero sea negativo (excepción)
     * 5-Que el número de la columna en la que se le asigna el asiento al pasajero esté fuera de rango (excepción)
     * 6-Que el asiento al que se le va a asignar al pasajero esté ya ocupado (false)
     * 7-Que el asiento al que se le va a asignar al pasajero no esté ocupado (true)
     */
    /**
     * Prueba 1 del método bookSeat
     * Que el pasajero sea null (excepción)
     */
    @Test
    public void testBookSeatWithNullPassenger()
    {
        try {
            //creamos unos parámetros correctos para la matriz
            int firstRows = SeatManager.MAX_FIRST_ROWS;
            int standardRows = SeatManager.MAX_STANDARD_ROWS;
            
            //creación del objeto persona
            Person person = null;
        
            //creamos un objeto SeatManager con los parámetros anteriores
            SeatManager sm = new SeatManager(firstRows,standardRows);
        
            //comprobación de que la matriz no sea null
            assertNotNull(sm.getSeats());
            
            //llamada al método
            sm.bookSeat(person,3,5);
            
            fail("Esperaba salto de excepción");
        } catch (IllegalArgumentException e){
            assertEquals("Esperaba pasajero pero fue null", e.getMessage());
        }
    }
    
    /**
     * Prueba 2 del método bookSeat
     * Que el número de la fila en la que se le asigna el asiento al pasajero sea negativo (excepción)
     */
    @Test
    public void testBookSeatWithNegativeRow()
    {
        try {
            //creamos unos parámetros correctos para la matriz
            int firstRows = SeatManager.MAX_FIRST_ROWS;
            int standardRows = SeatManager.MAX_STANDARD_ROWS;
            
            //creación del objeto persona
            Person person = new Person();
        
            //creamos un objeto SeatManager con los parámetros anteriores
            SeatManager sm = new SeatManager(firstRows,standardRows);
        
            //comprobación de que la matriz no sea null
            assertNotNull(sm.getSeats());
            
            //llamada al método
            sm.bookSeat(person,-3,5);
            
            fail("Esperaba salto de excepción");
        } catch (IllegalArgumentException e){
            assertEquals("Número de fila fuera de límite", e.getMessage());
        }
    }
    
    /**
     * Prueba 3 del método bookSeat
     * Que el número de la fila en la que se le asigna el asiento al pasajero esté fuera de rango (excepción)
     */
    @Test
    public void testBookSeatWithIncorrectRow()
    {
        try {
            //creamos unos parámetros correctos para la matriz
            int firstRows = SeatManager.MAX_FIRST_ROWS;
            int standardRows = SeatManager.MAX_STANDARD_ROWS;
            
            //creación del objeto persona
            Person person = new Person();
        
            //creamos un objeto SeatManager con los parámetros anteriores
            SeatManager sm = new SeatManager(firstRows,standardRows);
        
            //comprobación de que la matriz no sea null
            assertNotNull(sm.getSeats());
            
            //llamada al método
            sm.bookSeat(person,sm.getSeats().length + 1,5);
            
            fail("Esperaba salto de excepción");
        } catch (IllegalArgumentException e){
            assertEquals("Número de fila fuera de límite", e.getMessage());
        }
    }
    
    /**
     * Prueba 4 del método bookSeat
     * Que el número de la columna en la que se le asigna el asiento al pasajero sea negativo (excepción)
     */
    @Test
    public void testBookSeatWithNegativeColumn()
    {
        try {
            //creamos unos parámetros correctos para la matriz
            int firstRows = SeatManager.MAX_FIRST_ROWS;
            int standardRows = SeatManager.MAX_STANDARD_ROWS;
            
            //creación del objeto persona
            Person person = new Person();
        
            //creamos un objeto SeatManager con los parámetros anteriores
            SeatManager sm = new SeatManager(firstRows,standardRows);
        
            //comprobación de que la matriz no sea null
            assertNotNull(sm.getSeats());
            
            //llamada al método
            sm.bookSeat(person,5,-5);
            
            fail("Esperaba salto de excepción");
        } catch (IllegalArgumentException e){
            assertEquals("Número de columna fuera de límite", e.getMessage());
        }
    }
    
    /**
     * Prueba 5 del método bookSeat
     * Que el número de la columna en la que se le asigna el asiento al pasajero esté fuera de rango (excepción)
     */
    @Test
    public void testBookSeatWithIncorrectColumn()
    {
        try {
            //creamos unos parámetros correctos para la matriz
            int firstRows = SeatManager.MAX_FIRST_ROWS;
            int standardRows = SeatManager.MAX_STANDARD_ROWS;
            
            //creación del objeto persona
            Person person = new Person();
        
            //creamos un objeto SeatManager con los parámetros anteriores
            SeatManager sm = new SeatManager(firstRows,standardRows);
        
            //comprobación de que la matriz no sea null
            assertNotNull(sm.getSeats());
            
            //llamada al método
            sm.bookSeat(person,5,sm.getSeats().length + 1);
            
            fail("Esperaba salto de excepción");
        } catch (IllegalArgumentException e){
            assertEquals("Número de columna fuera de límite", e.getMessage());
        }
    }
    
    /**
     * Prueba 6 del método bookSeat
     * Que el asiento al que se le va a asignar al pasajero esté ya ocupado (false)
     */
    @Test
    public void testBookSeatWithOcuped()
    {
        //creamos unos parámetros correctos para la matriz
        int firstRows = SeatManager.MAX_FIRST_ROWS;
        int standardRows = SeatManager.MAX_STANDARD_ROWS;
          
        //creación de objetos persona
        Person person1 = new Person();
        Person person2 = new Person();
          
        //creamos un objeto SeatManager con los parámetros anteriores
        SeatManager sm = new SeatManager(firstRows,standardRows);
        
        //comprobación de que la matriz no sea null
        assertNotNull(sm.getSeats());
            
        //asignamos a una posición de la matriz el objeto person1
        sm.bookSeat(person1,5,5);
            
        //comprobación de resultados
        assertFalse(sm.bookSeat(person2,5,5));
    }
    
    /**
     * Prueba 7 del método bookSeat
     * Que el asiento al que se le va a asignar al pasajero no esté ocupado (true)
     */
    @Test
    public void testBookSeatWithFreeSeat()
    {
        //creamos unos parámetros correctos para la matriz
        int firstRows = SeatManager.MAX_FIRST_ROWS;
        int standardRows = SeatManager.MAX_STANDARD_ROWS;
            
        //creación del objeto persona
        Person person1 = new Person();
            
        //creamos un objeto SeatManager con los parámetros anteriores
        SeatManager sm = new SeatManager(firstRows,standardRows);
        
        //comprobación de que la matriz no sea null
        assertNotNull(sm.getSeats());
            
        //comprobación de resultados
        assertTrue(sm.bookSeat(person1,5,5));
    }
    
    /*
     * Pruebas del método releaseSeat con distintas condiciones
     * 1-Que tanto la fila como la columna que se introducen como parámetros, sean válidos
     * 2-Que tanto la fila como la columna que se introducen como parámetros, sean negativos (excepción)
     * 3-Que tanto la fila como la columna que se introducen como parámetros, estén por encima de los límites (excepción)
     * 4-Que la fila que se introduce como parámetro sea negativa y la columna sea válida (excepción)
     * 5-Que la fila que se introduce como parámetro esté por encima de los límites y la columna sea válida (excepción)
     * 6-Que la columna que se introduce como parámetro sea negativa y la fila sea válida (excepción)
     * 7-Que la columna que se introduce como parámetro esté por encima de los límites y la fila sea válida (excepción)
     */
    /**
     * Prueba 1 del método releaseSeat
     * Que tanto la fila como la columna que se introducen como parámetros, sean válidos
     */
    @Test
    public void testReleaseSeatWithCorrectParams()
    {
        //creación de los parámetros del constructor
        int firstRows = SeatManager.MAX_FIRST_ROWS;
        int standardRows = SeatManager.MAX_STANDARD_ROWS;
        
        //creación del objeto SeatManager
        SeatManager sm = new SeatManager(firstRows,standardRows);
        
        //comprobación de resultados
        assertEquals(sm.getSeats(3,3),sm.releaseSeat(3,3));
    }
    
    /**
     * Prueba 2 del método releaseSeat
     * Que tanto la fila como la columna que se introducen como parámetros, sean negativos (excepción)
     */
    @Test
    public void testReleaseSeatWithNegativeParams()
    {
        try{
            //creación de los parámetros del constructor
            int firstRows = SeatManager.MAX_FIRST_ROWS;
            int standardRows = SeatManager.MAX_STANDARD_ROWS;
        
            //creación del objeto SeatManager
            SeatManager sm = new SeatManager(firstRows,standardRows);
            
            //llamada al método
            sm.releaseSeat(-2,-2);
            
            fail("Esperaba salto de excepción");
        } catch (IllegalArgumentException e){
            assertEquals("Fila fuera de límites",e.getMessage());
        }
    }
    
    /**
     * Prueba 3 del método releaseSeat
     * Que tanto la fila como la columna que se introducen como parámetros, estén por encima de los límites (excepción)
     */
    @Test
    public void testReleaseSeatWithTooHighParams()
    {
        try{
            //creación de los parámetros del constructor
            int firstRows = SeatManager.MAX_FIRST_ROWS;
            int standardRows = SeatManager.MAX_STANDARD_ROWS;
        
            //creación del objeto SeatManager
            SeatManager sm = new SeatManager(firstRows,standardRows);
            
            //llamada al método
            sm.releaseSeat(100,100);
            
            fail("Esperaba salto de excepción");
        } catch (IllegalArgumentException e){
            assertEquals("Fila fuera de límites",e.getMessage());
        }
    }
    
    /**
     * Prueba 4 del método releaseSeat
     * Que la fila que se introduce como parámetro sea negativa y la columna sea válida (excepción)
     */
    @Test
    public void testReleaseSeatWithNegativeRow()
    {
        try{
            //creación de los parámetros del constructor
            int firstRows = SeatManager.MAX_FIRST_ROWS;
            int standardRows = SeatManager.MAX_STANDARD_ROWS;
        
            //creación del objeto SeatManager
            SeatManager sm = new SeatManager(firstRows,standardRows);
            
            //llamada al método
            sm.releaseSeat(-5,3);
            
            fail("Esperaba salto de excepción");
        } catch (IllegalArgumentException e){
            assertEquals("Fila fuera de límites",e.getMessage());
        }
    }
    
    /**
     * Prueba 5 del método releaseSeat
     * Que la fila que se introduce como parámetro esté por encima de los límites y la columna sea válida (excepción)
     */
    @Test
    public void testReleaseSeatWithTooHighRow()
    {
        try{
            //creación de los parámetros del constructor
            int firstRows = SeatManager.MAX_FIRST_ROWS;
            int standardRows = SeatManager.MAX_STANDARD_ROWS;
        
            //creación del objeto SeatManager
            SeatManager sm = new SeatManager(firstRows,standardRows);
            
            //llamada al método
            sm.releaseSeat(100,3);
            
            fail("Esperaba salto de excepción");
        } catch (IllegalArgumentException e){
            assertEquals("Fila fuera de límites",e.getMessage());
        }
    }
    
    /**
     * Prueba 6 del método releaseSeat
     * Que la columna que se introduce como parámetro sea negativa y la fila sea válida (excepción)
     */
    @Test
    public void testReleaseSeatWithNegativeColumn()
    {
        try{
            //creación de los parámetros del constructor
            int firstRows = SeatManager.MAX_FIRST_ROWS;
            int standardRows = SeatManager.MAX_STANDARD_ROWS;
        
            //creación del objeto SeatManager
            SeatManager sm = new SeatManager(firstRows,standardRows);
            
            //llamada al método
            sm.releaseSeat(3,-3);
            
            fail("Esperaba salto de excepción");
        } catch (IllegalArgumentException e){
            assertEquals("Columna fuera de límites",e.getMessage());
        }
    }
    
    /**
     * Prueba 7 del método releaseSeat
     * Que la columna que se introduce como parámetro esté por encima de los límites y la fila sea válida (excepción)
     */
    @Test
    public void testReleaseSeatWithTooHighColumn()
    {
        try{
            //creación de los parámetros del constructor
            int firstRows = SeatManager.MAX_FIRST_ROWS;
            int standardRows = SeatManager.MAX_STANDARD_ROWS;
        
            //creación del objeto SeatManager
            SeatManager sm = new SeatManager(firstRows,standardRows);
            
            //llamada al método
            sm.releaseSeat(3,300);
            
            fail("Esperaba salto de excepción");
        } catch (IllegalArgumentException e){
            assertEquals("Columna fuera de límites",e.getMessage());
        }
    }
    
    /*
     * Pruebas del método oldestPassenger con distintas condiciones
     * 1-Que no haya pasajeros (null)
     * 2-Que haya pasajero con la mayor edad
     */
    /**
     * Prueba 1 del método oldestPassenger 
     * Que no haya pasajeros (null)
     */
    @Test
    public void testOldestPassengerWithoutPassengers()
    {
        //creación de los parámetros 
        int firstRows = SeatManager.MAX_FIRST_ROWS;
        int standardRows = SeatManager.MAX_STANDARD_ROWS;
        
        //creación del objeto SeatManager
        SeatManager sm = new SeatManager(firstRows,standardRows);
        
        //comprobación de resultados
        assertNull(sm.oldestPassenger());
    }
    
    /**
     * Prueba 2 del método oldestPassenger 
     * Que haya pasajero con la mayor edad
     */
    @Test
    public void testOldestPassengerWithOldestPassenger()
    {
        //creación de los parámetros 
        int firstRows = SeatManager.MAX_FIRST_ROWS;
        int standardRows = SeatManager.MAX_STANDARD_ROWS;
        
        //creación del objeto SeatManager
        SeatManager sm = new SeatManager(firstRows,standardRows);
        
        for(int i = 0; i < sm.getSeats().length; i++)
        {
            for(int j = 0; j < sm.getSeats()[i].length; j++)
            {
                sm.getSeats()[i][j] = new Person();
            }
        }
        
        //comprobación de resultados
        assertNotNull(sm.oldestPassenger());
    }
    
    /*
     * Pruebas del método numberOfFreeSeats con distintas condiciones
     * 1-Que no haya asientos libres (contador = 0)
     * 2-Que haya asientos libres (contados > 0)
     */
    /**
     * Prueba 1 del método numberOfFreeSeats
     * Que no haya asientos libres (contador = 0)
     */
    @Test
    public void testNumberOfFreeSeatsWitoutFree()
    {
        //creación de los parámetros 
        int firstRows = SeatManager.MAX_FIRST_ROWS;
        int standardRows = SeatManager.MAX_STANDARD_ROWS;
        
        //creación del objeto SeatManager
        SeatManager sm = new SeatManager(firstRows,standardRows);
        
        //añadimos elementos a la matriz bidimensional
        for(int i = 0; i < sm.getSeats().length; i++)
        {
            for(int j = 0; j < sm.getSeats()[0].length; j++)
            {
                Person aux = new Person();
                sm.getSeats()[i][j] = aux;
            }
        }
        
        //comprobación de resultados
        assertEquals(0,sm.numberOfFreeSeats(2));
    }
    
    /**
     * Prueba 2 del método numberOfFreeSeats
     * Que haya asientos libres (contados > 0)
     */
    @Test
    public void testNumberOfFreeSeats()
    {
        //creación de los parámetros 
        int firstRows = SeatManager.MAX_FIRST_ROWS;
        int standardRows = SeatManager.MAX_STANDARD_ROWS;
        
        //creación del objeto SeatManager
        SeatManager sm = new SeatManager(firstRows,standardRows);
        
        //comprobación de resultados
        assertEquals(6,sm.numberOfFreeSeats(2));
    }
}
