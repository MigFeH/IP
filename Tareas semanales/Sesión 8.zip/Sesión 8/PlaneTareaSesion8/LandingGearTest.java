

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class LandingGearTest.
 *
 * @author  Miguel
 * @version 3-11-21
 */
public class LandingGearTest
{
    /**
     * Prueba del constructor sin parámetros
     * Crea un tren de aterrizaje con palanca down y tres puntales
     */
    @Test
    public void testLandingGearWithoutParam(){
        LandingGear landingGear1 = new LandingGear();
        
        assertEquals(landingGear1.LEVER_DOWN, landingGear1.getLever());
        assertNotNull(landingGear1.getLeft());
        assertNotNull(landingGear1.getRight());
        assertNotNull(landingGear1.getNose());
        //comprueba que no sean null (que existan)
    }
    
    /**
     * Prueba del constructor con parámetros
     * Crea un tren de aterrizaje con una palanca down
     * y tres puntales como parámetros (izquierdo, derecho y en el morro)
     */
    @Test
    public void testLandingGearWithParam(){
        WheelStrut left = new WheelStrut();
        WheelStrut right = new WheelStrut();
        WheelStrut nose = new WheelStrut();
        LandingGear landingGear1 = new LandingGear(left,right,nose);
        
        assertNotNull(landingGear1.getLeft());
        assertNotNull(landingGear1.getRight());
        assertNotNull(landingGear1.getNose());
        assertEquals(LandingGear.LEVER_DOWN, landingGear1.getLever());
    }
    
    /*
     * Pruebas del método moveLever en distintas condiciones:
     * 1-Acción Down cuando el tren está desplegado -> todo queda como está
     * 2-Acción Down cuando el tren está replegado -> se despliega y baja la palanca
     * 3-Acción Up cuando el tren está desplegado -> se repliega y sube la palanca
     * 4-Acción Up cuando el tren está replegado -> todo queda como está
     */
    /**
     * Prueba 1 de moveLever
     * Acción Down cuando el tren está desplegado -> todo queda como está
     */
    @Test 
    public void testMoveLeverDownWhenDeployed(){
        //situación inicial
        LandingGear landingGear1 = new LandingGear();   //me lo crea desplegado
        
        //lamada al método con el caso 1
        landingGear1.moveLever(LandingGear.LEVER_DOWN);
                
        
        
        //comprobación de resultados
        assertEquals(LandingGear.LEVER_DOWN, landingGear1.getLever());
        assertEquals(WheelStrut.IS_DEPLOYED, landingGear1.getLeft().isDeployed());
        assertEquals(WheelStrut.IS_DEPLOYED, landingGear1.getRight().isDeployed());
        assertEquals(WheelStrut.IS_DEPLOYED, landingGear1.getNose().isDeployed());
    }
    
    /**
     * Prueba 2 de moveLever
     * Acción Down cuando el tren está replegado -> se despliega y baja la palanca
     */
    @Test 
    public void testMoveLeverDownWhenRetracted(){
        //situación inicial
        LandingGear landingGear1 = new LandingGear();   //me lo crea desplegado
        landingGear1.moveLever(LandingGear.LEVER_UP); //lo retrae
        
        //lamada al método con el caso 2
        landingGear1.moveLever(LandingGear.LEVER_DOWN);
                
        
        
        //comprobación de resultados
        assertEquals(LandingGear.LEVER_DOWN, landingGear1.getLever());
        assertEquals(WheelStrut.IS_DEPLOYED, landingGear1.getLeft().isDeployed());
        assertEquals(WheelStrut.IS_DEPLOYED, landingGear1.getRight().isDeployed());
        assertEquals(WheelStrut.IS_DEPLOYED, landingGear1.getNose().isDeployed());
    }
    
    /**
     * Prueba 3 de moveLever
     * Acción Up cuando el tren está desplegado -> se repliega y sube la palanca
     */
    @Test
    public void testMoveLeverUpWhenDeployed(){
        LandingGear landingGear1 = new LandingGear();   //me lo crea desplegado
        
        landingGear1.moveLever(LandingGear.LEVER_UP);   //me lo repliega y sube palanca
        
        assertEquals(LandingGear.LEVER_UP, landingGear1.getLever());
        assertEquals(!WheelStrut.IS_DEPLOYED, landingGear1.getLeft().isDeployed());
        assertEquals(!WheelStrut.IS_DEPLOYED, landingGear1.getRight().isDeployed());
        assertEquals(!WheelStrut.IS_DEPLOYED, landingGear1.getNose().isDeployed());
    }
    
    /**
     * Prueba 4 de moveLever
     * Acción Up cuando el tren está replegado -> todo queda como está
     */
    @Test
    public void testMoveLeverUpWhenRetracted(){
        LandingGear landingGear1 = new LandingGear();   //me lo crea desplegado
        
        landingGear1.moveLever(LandingGear.LEVER_UP);   //mueve y deja la palanca arriba
        
        assertEquals(LandingGear.LEVER_UP, landingGear1.getLever());
        assertEquals(!WheelStrut.IS_DEPLOYED, landingGear1.getLeft().isDeployed());
        assertEquals(!WheelStrut.IS_DEPLOYED, landingGear1.getRight().isDeployed());
        assertEquals(!WheelStrut.IS_DEPLOYED, landingGear1.getNose().isDeployed());
    }
    
    /*
     * Pruebas del método test en distintas condiciones:
     * 1-Que el test del puntal izquierdo de false y el resto true
     * 2-Que el test del puntal derecho de false y el resto true
     * 3-Que el test del puntal del morro de false y el resto true
     * 4-Que el test del puntal izquierdo y derecho de false, y el resto true
     * 5-Que el test del puntal derecho y el del morro de false, y el resto true
     * 6-Que el test del puntal izquierdo y el del morro de false, y el resto true
     * 7-Que los tests de los tres puntales de false
     * 8-Que los tests de los tres puntales de true (devuelve true)
     */
    /**
     * Prueba 1 de test
     * Que el test del puntal izquierdo de false y el resto true
     */
    @Test
    public void testTestWithOnlyFalseLeft(){
        //creación de las ruedas del puntal false (izq)
        Wheel left1 = new Wheel(1000,100);  
        Wheel right1 = new Wheel(1000,1000);
        
        //creación del puntal izquierdo false
        WheelStrut left2 = new WheelStrut(WheelStrut.IS_DEPLOYED, left1, right1);
        
        //creación del resto de puntales correctos
        WheelStrut right2 = new WheelStrut();
        WheelStrut nose2 = new WheelStrut();
        
        //creación del tren de aterrizaje
        LandingGear landingGear1 = new LandingGear(left2, right2, nose2);
        
        //llamada al método
        landingGear1.test();
        
        //comprobación de resultados
        assertEquals(left2.test(),landingGear1.test());
        assertEquals(right2.test(),landingGear1.test());
        assertEquals(nose2.test(),landingGear1.test());
    }
    
    /**
     * Prueba 2 de test
     * Que el test del puntal derecho de false y el resto true
     */
    @Test
    public void testTestWithOnlyFalseRight(){
        //creación de las ruedas del puntal false (dcha)
        Wheel left1 = new Wheel(1000,100);  
        Wheel right1 = new Wheel(1000,1000);
        
        //creación del puntal derecho false
        WheelStrut right2 = new WheelStrut(WheelStrut.IS_DEPLOYED, left1, right1);
        
        //creación del resto de puntales correctos
        WheelStrut left2 = new WheelStrut();
        WheelStrut nose2 = new WheelStrut();
        
        //creación del tren de aterrizaje
        LandingGear landingGear1 = new LandingGear(left2, right2, nose2);
        
        //llamada al método
        landingGear1.test();
        
        //comprobación de resultados
        assertEquals(left2.test(),landingGear1.test());
        assertEquals(right2.test(),landingGear1.test());
        assertEquals(nose2.test(),landingGear1.test());
    }
    
    /**
     * Prueba 3 de test
     * Que el test del puntal del morro de false y el resto true
     */
    @Test
    public void testTestWithOnlyFalseNose(){
        //creación de las ruedas del puntal false (morro)
        Wheel left1 = new Wheel(1000,100);  
        Wheel right1 = new Wheel(1000,1000);
        
        //creación del puntal del morro false
        WheelStrut nose2 = new WheelStrut(WheelStrut.IS_DEPLOYED, left1, right1);
        
        //creación del resto de puntales correctos
        WheelStrut left2 = new WheelStrut();
        WheelStrut right2 = new WheelStrut();
        
        //creación del tren de aterrizaje
        LandingGear landingGear1 = new LandingGear(left2, right2, nose2);
        
        //llamada al método
        landingGear1.test();
        
        //comprobación de resultados
        assertEquals(left2.test(),landingGear1.test());
        assertEquals(right2.test(),landingGear1.test());
        assertEquals(nose2.test(),landingGear1.test());
    }
    
    /**
     * Prueba 4 de test
     * Que el test del puntal izquierdo y derecho de false, y el resto true
     */
    @Test
    public void testTestWithFalseLeftAndRight(){
        //creación de las ruedas del puntal false (izquierdo y derecho)
        Wheel left1 = new Wheel(1000,100);  
        Wheel right1 = new Wheel(1000,1000);
        
        //creación del puntal izquierdo y derecho false
        WheelStrut left2 = new WheelStrut(WheelStrut.IS_DEPLOYED, left1, right1);
        WheelStrut right2 = new WheelStrut(WheelStrut.IS_DEPLOYED, left1, right1);
        
        //creación del resto de puntales correctos
        WheelStrut nose2 = new WheelStrut();
        
        //creación del tren de aterrizaje
        LandingGear landingGear1 = new LandingGear(left2, right2, nose2);
        
        //llamada al método
        landingGear1.test();
        
        //comprobación de resultados
        assertEquals(left2.test(),landingGear1.test());
        assertEquals(right2.test(),landingGear1.test());
        assertEquals(nose2.test(),landingGear1.test());
    }
    
    /**
     * Prueba 5 de test
     * Que el test del puntal derecho y el del morro de false, y el resto true
     */
    @Test
    public void testTestWithFalseRightAndNose(){
        //creación de las ruedas del puntal false (derecho y el del morro)
        Wheel left1 = new Wheel(1000,100);  
        Wheel right1 = new Wheel(1000,1000);
        
        //creación del puntal derecho y del del morro false
        WheelStrut nose2 = new WheelStrut(WheelStrut.IS_DEPLOYED, left1, right1);
        WheelStrut right2 = new WheelStrut(WheelStrut.IS_DEPLOYED, left1, right1);
        
        //creación del resto de puntales correctos
        WheelStrut left2 = new WheelStrut();
        
        //creación del tren de aterrizaje
        LandingGear landingGear1 = new LandingGear(left2, right2, nose2);
        
        //llamada al método
        landingGear1.test();
        
        //comprobación de resultados
        assertEquals(left2.test(),landingGear1.test());
        assertEquals(right2.test(),landingGear1.test());
        assertEquals(nose2.test(),landingGear1.test());
    }
    
    /**
     * Prueba 6 de test
     * Que el test del puntal izquierdo y el del morro de false, y el resto true
     */
    @Test
    public void testTestWithFalseLeftAndNose(){
        //creación de las ruedas del puntal false (izquierdo y el del morro)
        Wheel left1 = new Wheel(1000,100);  
        Wheel right1 = new Wheel(1000,1000);
        
        //creación del puntal izquierdo y del del morro false
        WheelStrut nose2 = new WheelStrut(WheelStrut.IS_DEPLOYED, left1, right1);
        WheelStrut left2 = new WheelStrut(WheelStrut.IS_DEPLOYED, left1, right1);
        
        //creación del resto de puntales correctos
        WheelStrut right2 = new WheelStrut();
        
        //creación del tren de aterrizaje
        LandingGear landingGear1 = new LandingGear(left2, right2, nose2);
        
        //llamada al método
        landingGear1.test();
        
        //comprobación de resultados
        assertEquals(left2.test(),landingGear1.test());
        assertEquals(right2.test(),landingGear1.test());
        assertEquals(nose2.test(),landingGear1.test());
    }
    
    /**
     * Prueba 7 de test
     * Que los tests de los tres puntales de false
     */
    @Test
    public void testTestWithAllFalse(){
        //creación de las ruedas de los puntales false
        Wheel left1 = new Wheel(1000,100);  
        Wheel right1 = new Wheel(1000,1000);
        
        //creación de los puntales false
        WheelStrut left2 = new WheelStrut(WheelStrut.IS_DEPLOYED, left1, right1);
        WheelStrut right2 = new WheelStrut(WheelStrut.IS_DEPLOYED, left1, right1);
        WheelStrut nose2 = new WheelStrut(WheelStrut.IS_DEPLOYED, left1, right1);
        
        //creación del tren de aterrizaje
        LandingGear landingGear1 = new LandingGear(left2, right2, nose2);
        
        //llamada al método
        landingGear1.test();
        
        //comprobación de resultados
        assertEquals(left2.test(),landingGear1.test());
        assertEquals(right2.test(),landingGear1.test());
        assertEquals(nose2.test(),landingGear1.test());
    }
    
    /**
     * Prueba 8 de test
     * Que los tests de los tres puntales de true (devuelve true)
     */
    @Test
    public void testTestWithAllTrue(){
        //creación del tren de aterrizaje sin parámetros
        LandingGear landingGear1 = new LandingGear();
        
        //llamada al método
        landingGear1.test();
        
        //comprobación de resultados
        assertEquals(landingGear1.getLeft().test() ,landingGear1.test());
        assertEquals(landingGear1.getRight().test() ,landingGear1.test());
        assertEquals(landingGear1.getNose().test() ,landingGear1.test());        
    }
    
    /**
     * Pruebas del método toString 
     */
    @Test
    public void testToString(){
        LandingGear landingGear1 = new LandingGear();
        
        landingGear1.moveLever(LandingGear.LEVER_UP);
        
        assertEquals("Lever: UP    Status: OK    Nose: ON    Left: ON    Right: ON",
                        landingGear1.toString());
    }
}
