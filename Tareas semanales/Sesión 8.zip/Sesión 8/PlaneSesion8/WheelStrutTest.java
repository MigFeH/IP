

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class WheelStrutTest.
 *
 * @author  Miguel
 * @version 27-10-21
 */
public class WheelStrutTest
{
    /**
     * Pruebas para el constructor sin parámetros
     * Creará un puntal desplegado con dos ruedas con la presión del BOEING 737
     */
    @Test
    public void testWheelStrutWithoutParams(){
        WheelStrut wheelStrut1 = new WheelStrut();
        assertEquals(WheelStrut.IS_DEPLOYED, wheelStrut1.isDeployed());
        
        assertNotNull(wheelStrut1.getLeftWheel()); //Comprobamos que no sea null
        assertEquals(WheelStrut.BOEING_737_PRESSURE, wheelStrut1.getLeftWheel().getPressure(), 0.1); //El 0.1 son los decimales con los que calculamos
        assertEquals(WheelStrut.BOEING_737_PRESSURE, wheelStrut1.getLeftWheel().getMaxPressure(), 0.1); //El 0.1 son los decimales con los que calculamos
        
        assertNotNull(wheelStrut1.getRightWheel()); //Comprobamos que no sea null
        assertEquals(WheelStrut.BOEING_737_PRESSURE, wheelStrut1.getRightWheel().getPressure(), 0.1); //El 0.1 son los decimales con los que calculamos
        assertEquals(WheelStrut.BOEING_737_PRESSURE, wheelStrut1.getRightWheel().getMaxPressure(), 0.1); //El 0.1 son los decimales con los que calculamos
    }
    
    /*
     * Pruebas del método test
     * Casos:
     * 1-Ambas ruedas con presión correcta -> true
     * 2-Ambas ruedas con presión incorrecta -> false
     * 3-Rueda izquierda con presión incorrecta y derecha correcta -> false
     * 4-Rueda derecha con presión incorrecta e izquierda correcta -> false
    */
    /**
     * Pruebas del método test
     * Caso 3: Rueda izquierda con presión incorrecta y derecha correcta -> false
     */
    @Test
    public void testTestLeftWrongRightOK(){
        //Situación inicial: puntal con rueda izquierda mal y derecha bien
        Wheel leftWrong = new Wheel(5000,1000);
        Wheel rightOK = new Wheel(5000,5000);
        WheelStrut wheelStrut1 = new WheelStrut(leftWrong, rightOK);
        
        //Llamar al método a probar:  ----- assertTrue(wheelStrut.test())
        boolean result = wheelStrut1.test();
        
        //Comprobar resultados:
        assertEquals(true, result); //Es lo mismo assertTrue(result);
    }
    
    /**
     * Pruebas del método test
     * Caso 1: Ambas ruedas con presión correcta -> true
     */
    @Test
    public void testTestAllOK(){
        Wheel left = new Wheel(5000,5000);
        Wheel right = new Wheel(5000,5000);
        WheelStrut wheelStrut1 = new WheelStrut();
        assertEquals(true, wheelStrut1.test());
    }
    
    /**
     * Pruebas del método test
     * Caso 2: Ambas ruedas con presión incorrecta -> false
     */
    @Test
    public void testTestAllWrong(){
        Wheel leftWrong = new Wheel(5000,1000);
        Wheel rightWrong = new Wheel(5000,1000);
        WheelStrut wheelStrut1 = new WheelStrut(leftWrong, rightWrong);
        assertEquals(true,wheelStrut1.test());
    }
    
    /**
     * Pruebas del método test
     * Caso 4: Rueda derecha con presión incorrecta e izquierda correcta -> false
     */
    @Test
    public void testTestRightWrongLeftOK(){
        Wheel leftOK = new Wheel(5000,5000);
        Wheel rightWrong = new Wheel(5000,1000);
        WheelStrut wheelStrut1 = new WheelStrut(leftOK, rightWrong);
        assertEquals(true,wheelStrut1.test());
    }
    
    /*
     * Pruebas de deploy
     * 1- Estando replegado, lo despliega
     * 2- Estando desplegado, lo deja como está
     */
    /**
     * Prueba 1 del método deploy
     */
    @Test
    public void testDeployWhenRetracted(){
        //situación inicial
        Wheel right = new Wheel();
        Wheel left = new Wheel();
        WheelStrut wh1 = new WheelStrut( !WheelStrut.IS_DEPLOYED,left,right);
        
        //llamada al método
        wh1.deploy();
        
        //comprobación de resultado
        assertEquals(WheelStrut.IS_DEPLOYED, wh1.isDeployed());
    }
    
    /**
     * Prueba 2 del método deploy
     */
    @Test
    public void testDeployWhenDeployed(){
        Wheel right = new Wheel();
        Wheel left = new Wheel();
        WheelStrut wh1 = new WheelStrut(WheelStrut.IS_DEPLOYED,left,right);
        wh1.deploy();
        assertEquals(WheelStrut.IS_DEPLOYED, wh1.isDeployed());
    }
    
    /*
     * Pruebas retracted
     * 1- Estando replegado, lo deja como está
     * 2- Estando desplegado, lo repliega
     */
    /**
     * Prueba 1 del método retracted
     */
    @Test
    public void testRetractedWhenRetracted(){
        Wheel right = new Wheel();
        Wheel left = new Wheel();
        WheelStrut wh1 = new WheelStrut(!WheelStrut.IS_DEPLOYED,left,right);
        wh1.retract();
        assertEquals(!WheelStrut.IS_DEPLOYED,wh1.isDeployed());
    }
    
    /**
     * Prueba 2 del método retracted
     */
    @Test
    public void testRetractedWhenDeployed(){
        Wheel right = new Wheel();
        Wheel left = new Wheel();
        WheelStrut wh1 = new WheelStrut(WheelStrut.IS_DEPLOYED,left,right);
        wh1.retract();
        assertEquals(!WheelStrut.IS_DEPLOYED,wh1.isDeployed());
    }   
}
