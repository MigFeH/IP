
/**
 * Tren de aterrizaje del avión con palanca, puntales
 * izquierdo, derecho y morro
 * 
 * @author Miguel 
 * @version 3-11-21
 */
public class LandingGear
{
    //constantes
    public static final boolean LEVER_UP = true;
    public static final boolean LEVER_DOWN = false;
    
    //variables de instancia
    private boolean lever;  //palanca para mover los puntales del tren de aterrizaje
    private WheelStrut left;    //puntal izquierdo
    private WheelStrut right;   //puntal derecho
    private WheelStrut nose;    //puntal del morro
    /**
     * Constructor de la clase LandingGear con lever down y tres puntales
     */
    public LandingGear()
    {
        setLever(LEVER_DOWN);
        setLeft(new WheelStrut());
        setRight(new WheelStrut());
        setNose(new WheelStrut());
    }
    
    /**
     * Constructor de la clase LandingGear con los puntales como parámetros
     * @param left
     * @param right
     * @param nose
     */
    public LandingGear(WheelStrut left, WheelStrut right, WheelStrut nose)
    {
        this();
        setLeft(left);
        setRight(right);
        setNose(nose);
        left.deploy();
        right.deploy();
        nose.deploy();
    }
    
    /**
     * Modifica el valor del atributo lever
     * @param nuevo valor
     */
    private void setLever (boolean lever){
        this.lever = lever;
    }
    
    /**
     * Modifica el valor del atributo left
     * @param nuevo valor
     */
    private void setLeft (WheelStrut left){
        checkParam(left != null,"Esperaba puntal left en lugar de null");
        this.left = left;
    }
    
    /**
     * Modifica el valor del atributo right
     * @param nuevo valor
     */
    private void setRight (WheelStrut right){
        checkParam(right != null,"Esperaba puntal right en lugar de null");
        this.right = right;
    }
    
    /**
     * Modifica el valor del atributo nose
     * @param nuevo valor
     */
    private void setNose (WheelStrut nose){
        checkParam(nose != null,"Esperaba puntal nose en lugar de null");
        this.nose = nose;
    }
    
    /**
     * Retorna el valor de lever
     * @return valor de la palanca
     */
    public boolean getLever(){
        return lever;    
    }
    
    /**
     * Retorna el valor de left
     * @return valor del puntal izquierdo
     */
    public WheelStrut getLeft(){
        return left;    
    }
    
    /**
     * Retorna el valor de right
     * @return valor del puntal derecho
     */
    public WheelStrut getRight(){
        return right;    
    }
    
    /**
     * Retorna el valor de nose
     * @return valor del morro
     */
    public WheelStrut getNose(){
        return nose;    
    }
    
    /**
     * Mueve la palanca a LEVER_UP o LEVER_DOWN
     * y repliega o despliega los puntales
     * @param action LEVER_UP o LEVER_DOWN
     */
    public void moveLever(boolean action){
        setLever(action);
        if (action == LEVER_DOWN){    //si la mueve abajo, lo despliega
            left.deploy();
            right.deploy();
            nose.deploy();
        } else {    //sino, lo repliega
            left.retract();
            right.retract();
            nose.retract();
        }
    }
    
    private void checkParam (boolean condition, String msg){
        if (!condition){
            throw new IllegalArgumentException(msg);
        }
    }
}
