

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class LandingGearTest.
 *
 * @author  Miguel
 * @version 3-11-21
 */
public class LandingGearTest
{
    /**
     * Prueba del constructor sin parámetros
     * Crea un tren de aterrizaje con palanca down y tres puntales
     */
    @Test
    public void testLandingGearWithoutParam(){
        LandingGear landingGear1 = new LandingGear();
        assertEquals(landingGear1.LEVER_DOWN, landingGear1.getLever());
        assertNotNull(landingGear1.getLeft());
        assertNotNull(landingGear1.getRight());
        assertNotNull(landingGear1.getNose());
        //comprueba que no sean null (que existan)
    }
    
    /**
     * Pruebas de moveLever
     * Casos de uso:
     * 1-Acción Down cuando el tren está desplegado -> todo queda como está
     * 2-Acción Down cuando el tren está replegado -> se despliega y baja la palanca
     * 3-Acción Up cuando el tren está desplegado -> se repliega y sube la palanca
     * 4-Acción Up cuando el tren está replegado -> todo queda como está
     */
    @Test 
    public void testMoveLeverDownWhenDeployed(){
        //situación inicial
        LandingGear landingGear1 = new LandingGear();   //me lo crea desplegado
        
        //lamada al método con el caso 1
        landingGear1.moveLever(LandingGear.LEVER_DOWN);
                
        
        
        //comprobación de resultados
        assertEquals(LandingGear.LEVER_DOWN, landingGear1.getLever());
        assertEquals(WheelStrut.IS_DEPLOYED, landingGear1.getLeft().isDeployed());
        assertEquals(WheelStrut.IS_DEPLOYED, landingGear1.getRight().isDeployed());
        assertEquals(WheelStrut.IS_DEPLOYED, landingGear1.getNose().isDeployed());
    }
    
    @Test 
    public void testMoveLeverDownWhenRetracted(){
        //situación inicial
        LandingGear landingGear1 = new LandingGear();   //me lo crea desplegado
        landingGear1.moveLever(LandingGear.LEVER_UP); //lo retrae
        
        //lamada al método con el caso 2
        landingGear1.moveLever(LandingGear.LEVER_DOWN);
                
        
        
        //comprobación de resultados
        assertEquals(LandingGear.LEVER_DOWN, landingGear1.getLever());
        assertEquals(WheelStrut.IS_DEPLOYED, landingGear1.getLeft().isDeployed());
        assertEquals(WheelStrut.IS_DEPLOYED, landingGear1.getRight().isDeployed());
        assertEquals(WheelStrut.IS_DEPLOYED, landingGear1.getNose().isDeployed());
    }
}
