

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class MatrixTest
{
    /**
     * Default constructor for test class MatrixTest
     */
    public MatrixTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    
    @Test
    public void testConstructorIntParameter()
    {
        Matrix matrix=new Matrix(2);
        // ....
    }
    
    @Test
    public void testConstructorArrayParameter()
    {
        Matrix matrix=new Matrix(new int[][]{{1, 0}, {0, 1}});
        // ....
    }
    
    @Test
    public void testGetAverage()
    {
        Matrix matrix=new Matrix(new int[][]{{1, 0}, {0, 1}});
        //....
        
        
    }

    @Test
    public void testAddByColumns()()    {
        Matrix matrix=new Matrix(new int[][]{{1, 0}, {0, 1}});

        int[]expected = {1,1};
        assertArrayEquals(expected, matrix.addByColumns());
        // ....
    }    
    
     

    @Test
    public void testSwapColumns()
    {
        Matrix matrix=new Matrix(new int[][]{{1, 0}, {0, 1}});
        //...
    }    


    @Test
    public void testRotateMatrix()
    {
        Matrix matrix=new Matrix(new int[][]{{1, 0}, {0, 1}});
        //...
    }    
    
    @Test
    public void testGetMaxAdjacentValue()
    {
        Matrix matrix=new Matrix(new int[][]{{1, 0}, {0, 1}});
        //...
    }   

    @Test
    public void testSmoothMatrix()
    {
        Matrix matrix=new Matrix(new int[][]{{1, 0}, {0, 1}});
        //...
    }     
     
}
